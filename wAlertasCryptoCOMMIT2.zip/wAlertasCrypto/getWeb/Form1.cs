﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace getWeb
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnWeb_Click(object sender, EventArgs e)
        {


        }

        private void timer_Tick(object sender, EventArgs e)
        {
            webBrowser1.Refresh();
            string Cadena = "COP$";
            //webBrowser1.Navigate = ("https://www.dolar-colombia.com/en/");
            
            rtfHTML.Text = webBrowser1.Document.Body.OuterHtml;

            for (int i = 0; i < rtfHTML.Lines.Length; i++)
            {                
                string linea = rtfHTML.Lines[i];
                if (linea.Contains(Cadena))
                {
                    int index = linea.IndexOf(Cadena);
                    MessageBox.Show(linea.Substring(index + 4, 9));
                    i = rtfHTML.Lines.Length;  //Asigno a la vble del ciclo el valor máximo para que no continue
                 
                }

            }

        }
    }
}
