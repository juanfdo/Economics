﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace wAlertasCrypto
{
    class sumidero
    {
        public static string estrategiaActiva;
    }
}
