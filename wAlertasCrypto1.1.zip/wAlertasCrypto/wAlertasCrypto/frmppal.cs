﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Diagnostics;
using System.Net;
using RestSharp;
using System.Security.Cryptography;
using System.Globalization;
using System.Windows.Forms.DataVisualization.Charting;

namespace wAlertasCrypto
{
    public partial class frmPpal : Form
    {
        
        public frmPpal()
        {
            InitializeComponent();
        }
        private Stream myStream;
        int counter = 0;
        string line;
        string ruta = Application.StartupPath;
        public string apiKey = "";
        public string secretKey = "";
        DateTime newFecha = DateTime.Now;
        private string f;
        //Obtener el valor del dolar al día
        public double VlrDolar = 0;
        public Boolean flag0 = false;
        public DateTime tiempoinicial = DateTime.Now;
        public DateTime tiempofinal = DateTime.Now;
        //Variables para la red neuronal
        //compra
        public double RNA_EMA_compra = 0 ;
        public double RNA_RSI_compra = 0 ;
        public double RNA_MACD_compra = 0;
        public double RNA_SAR_compra = 0;
        public double RNA_m1_compra = 0;
        public double RNA_m5_compra = 0;
        public double RNA_m15_compra = 0;
        public double RNA_m30_compra = 0;
        public double RNA_H1_compra = 0;
        public double RNA_H4_compra = 0;
        public double RNA_W1_compra = 0;
        public double RNA_M1_compra = 0;
        //venta
        public double RNA_EMA_venta = 0;
        public double RNA_RSI_venta = 0;
        public double RNA_MACD_venta = 0;
        public double RNA_SAR_venta = 0;
        public double RNA_m1_venta = 0;
        public double RNA_m5_venta = 0;
        public double RNA_m15_venta = 0;
        public double RNA_m30_venta = 0;
        public double RNA_H1_venta = 0;
        public double RNA_H4_venta = 0;
        public double RNA_W1_venta = 0;
        public double RNA_M1_venta = 0;
        // Variables para Distribucion de Valor
        public double BTC_vlr = 0;
        public double XRP = 0;
        //Obtener valor dolar cada minuto y no cada 20 seg
        public int CallDolar = 0;


        public void WBS_dolar()
        {
            // Obtener el valor del Dolar a través del consumo WEB
            try
            {
                ProcessStartInfo startInfo = new ProcessStartInfo();
                startInfo.CreateNoWindow.ToString();
                startInfo.FileName = ruta + "\\GetDolarH.lnk";
                startInfo.Arguments = f;
                Process.Start(startInfo);
                //Leer valor del dolar
                char[] separators = { ',', '!', '?', ';', ':', ' ', '{', '}', '"' };
                string[] dolar;
                Application.DoEvents();
                System.IO.StreamReader file = new System.IO.StreamReader(ruta + @"\dolar.txt");
                while ((line = file.ReadLine()) != null)
                {
                    {
                        dolar = line.Split(separators, StringSplitOptions.RemoveEmptyEntries);
                        if (dolar.Length > 0)
                        {
                            if (dolar[0] == "ratetrm")
                            {
                                VlrDolar = Convert.ToDouble(dolar[1].Replace(".", ","));
                                if (VlrDolar.ToString() != "")
                                {
                                    lblDolarvl.Text = VlrDolar.ToString();
                                    txtVlrDolar.Text = VlrDolar.ToString();
                                    VlrDolar = Convert.ToDouble(dolar[1]);
                                }

                            }
                        }
                    }
                }
                file.Close();

            }
            catch (Exception)
            {
                //throw;
                string path2 = ruta + @"\log\logErrors.txt";
                string debug = "\n" + DateTime.Today.ToString() + "-" + "Err:Consumo de servicio Valor Dolar.";
                File.AppendAllText(path2, debug);
            }
        }


        private void cmdTEst_Click(object sender, EventArgs e)
        {
 
            var client = new RestClient("http://api.hitbtc.com");

            var request = new RestRequest("/api/2/payment/balance", Method.GET);
            request.AddParameter("nonce", GetNonce());
            request.AddParameter("apikey", apiKey);

            string sign = CalculateSignature(client.BuildUri(request).PathAndQuery, secretKey);
            request.AddHeader("X-Signature", sign);

            var response = client.Execute(request);
            string VlrBTC = (response.Content);
            char[] separators = { ',', '!', '?', ';', ':', ' ', '{', '}','[', '"' };
            string[] words;
            string[] cuentas = new string[251];
            string[] cuentasT = new string[500];
            string[] cuentasT2 = new string[250];
            int cont = 0;
            words = VlrBTC.Split(separators, StringSplitOptions.RemoveEmptyEntries);
            for (int i = 2; i < (cuentas.Length-1); i+=4)
            {
                cuentas[cont] = words[i] + "-" + words[i + 2] + "-";
                cont++;
            }
            //-------------------------------------------------------------------------

            var request2 = new RestRequest("/api/1/trading/balance", Method.GET);
            request2.AddParameter("nonce", GetNonce());
            request2.AddParameter("apikey", apiKey);

            string sign2 = CalculateSignature(client.BuildUri(request2).PathAndQuery, secretKey);
            request2.AddHeader("X-Signature", sign2);
            var response2 = client.Execute(request2);
            string Poftfolio = (response2.Content);
            string[] words2;
            words2 = Poftfolio.Split(separators, StringSplitOptions.RemoveEmptyEntries);
            cont = 0;
            
            for (int i = 2; i < cuentasT.Length; i += 3)
            {
                cuentasT[cont] = words2[i] + "-" + words2[i + 2];
                cont++;
            }
            int cont2 = 0;
            for (int i = 0; i < cuentasT.Length; i+=2)
            {
                cuentasT2[cont2] = cuentasT[i];
                cont2++;
            }

            for (int i = 0; i < cuentas.Length - 2; i ++)
            {
                string[] confrontar = new string[3];
                string[] confrontarT = new string[3];
                cuentas[i] = cuentas[i] + "0";
                confrontar = cuentas[i].Split('-');

                for (int j = 0; j < (cuentasT2.Length); j++)
                {
                    if (String.IsNullOrEmpty(cuentas[j]))
                    {
                        flag0 = false;

                    }
                    else
                    {
                        flag0 = true;
                    }
                
                    if (String.IsNullOrEmpty(cuentasT2[j]) || (flag0 == true))
                    {
                        confrontarT[0] = "0";
                        confrontarT[1] = "0";
                        confrontarT[2] = "0";
                    }
                    else
                    {
                        confrontarT = cuentasT2[j].Split('-');
                    }                        
                    
                if (confrontar[0].ToString() == confrontarT[0].ToString())
                    {                        
                        double value = Convert.ToDouble(confrontarT[1]);                        
                        cuentas[i] = cuentas[i] + confrontarT[1].ToString();
                    }
                }

            }

            for (int i = 0; i < cuentas.Length; i++)
            {
                string[] confrontar = cuentas[i].Split('-');
                if (String.IsNullOrEmpty(confrontar[2]))
                {
                    confrontar[2] = "0";
                }
                string c1 = confrontar[1];
                c1.Replace(".", ",");
                confrontar[1] = c1;

                c1 = confrontar[2];
                c1.Replace(".", ",");
                confrontar[2] = c1;
                //confrontar[2].Replace(".", ",");
                if (Convert.ToDouble(confrontar[1]) != Convert.ToDouble(confrontar[2])) {
                    //double TotalUnid = decimal.Parse(confrontar[1]).ToString() + decimal.Parse(confrontar[2]).ToString();
                    double TotalUnid = Convert.ToDouble(confrontar[1]) + Convert.ToDouble(confrontar[2]);
                    dtgAssestHitBTC.Rows.Add (confrontar[0] , confrontar[1] , confrontar[2], TotalUnid);
                }
                
            }




            //// create Datagridview image column
            //DataGridViewImageColumn dgvImageColumn = new DataGridViewImageColumn();
            //// set header text to the column
            //dgvImageColumn.HeaderText = "Image";
            //// display the entire image
            //dgvImageColumn.ImageLayout = DataGridViewImageCellLayout.Stretch;

            //// create Datagridview text column
            //DataGridViewTextBoxColumn dgvIdColumn = new DataGridViewTextBoxColumn();
            //dgvIdColumn.HeaderText = "Id";

            //dtgPic.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

            //dtgPic.RowTemplate.Height = 130;

            //dtgPic.AllowUserToAddRows = false;


            //dtgPic.Columns.Add(dgvIdColumn);
            //dtgPic.Columns.Add(dgvImageColumn);

            //// create and add images to the dataGridView
            //Image img1;
            //img1 = Image.FromFile(@"C:\iconos\test.jpg");
            //dtgPic.Rows.Add("RTUIKJGRR", img1);


            //Icon treeIcon = new Icon(this.GetType(), "test.png");
            //DataGridViewImageColumn iconColumn = new DataGridViewImageColumn();
            //iconColumn.Image = treeIcon.ToBitmap();
            //iconColumn.Name = "Tree";
            //iconColumn.HeaderText = "Nice tree";
            //dtgPic.Columns.Insert(2, iconColumn);
            ///**********************************
            //MemoryStream mmst = new MemoryStream();
            //picBTC.Image.Save(mmst, picBTC.Image.RawFormat);
            //byte[] img = mmst.ToArray();
            ////dtgPic.Columns.Add(img);
            //dtgPic.Rows.Add(img);

            //*******************************
            //DataGridViewImageColumn img = new DataGridViewImageColumn();
            //Image image = Image.FromFile("C:\\iconos\\test.jpg");
            //img.Image = image;
            //dtgPic.Columns.Add(img);
            //img.HeaderText = "Image";
            //img.Name = "img";
            // dtgPic


        }

        private static long GetNonce()
        {
            return DateTime.Now.Ticks * 10 / TimeSpan.TicksPerMillisecond; // use millisecond timestamp or whatever you want
        }
        public static string CalculateSignature(string text, string secretKey)
        {
            using (var hmacsha512 = new HMACSHA512(Encoding.UTF8.GetBytes(secretKey)))
            {
                hmacsha512.ComputeHash(Encoding.UTF8.GetBytes(text));
                return string.Concat(hmacsha512.Hash.Select(b => b.ToString("x2")).ToArray()); // minimalistic hex-encoding and lower case
            }
        }

        public void WBS_AltCoins()
        {
            var VlrBTC = "";
            var VlrETH = "";
            var vlrLtc = "";
            var vlrXRP = "";
            var vlrDGB = "";
            var vlrPIVX = "";
            var vlrBCN = "";

            //LLevar a un archivo de configuración cifrado!!
            //  const string apiKey = "26dd38504e39df9241e8d9860062af22";
            // const string secretKey = "f908c5ba21775e87865d2ef035fb8282";


            //-----------------------------------------------
            char[] separators = { ',', '!', '?', ';', ':', ' ', '{', '}', '"' };
            string[] words;
            string[] words1;
            string[] words2;
            string[] words3;
            string[] words4;
            string[] words5;
            string[] words6;
            //Limpiar Grids
            dtGCSV.Rows.Clear();

            //*** Verificar la utilización de la API
            //https://api.hitbtc.com/api/1/public/ticker
            //Esta obtiene todos los valores en una sola llamada!!!!!!

            rtxtLog.Text = rtxtLog.Text + "\r" + newFecha.ToString() + " - " + "Obteniendo valores actuales de monedas...";
            //Obtener el valor del BitCoin al día USD
            var client = new RestClient("http://api.hitbtc.com");
            var request = new RestRequest("/api/1/public/BTCUSD/ticker", Method.GET);
            request.AddParameter("nonce", GetNonce());
            request.AddParameter("apikey", apiKey);
            string sign = CalculateSignature(client.BuildUri(request).PathAndQuery, secretKey);
            request.AddHeader("X-Signature", sign);
            var response = client.Execute(request);
            VlrBTC = (response.Content);
            words = VlrBTC.Split(separators, StringSplitOptions.RemoveEmptyEntries);
            double vlrPesos = Convert.ToDouble(words[3].Replace(".", ","));
            vlrPesos = vlrPesos * VlrDolar;
            //** Cargar la imagen en la fila
            Bitmap img;
            //string ruta = Application.StartupPath;
            img = new Bitmap(ruta + "\\resources\\bitcoin_16.png");
            //dtGCSV.Rows.Add();
            //dtGCSV.Rows[1].Cells[4].Value = img;
            //*************************
            dtGCSV.Rows.Add(img,"BitCoin", "1", words[3], vlrPesos.ToString());
            //----------------------------------------------------------------------------

            //Obtener el valor del Ethereum al día USD-COP
            var client1 = new RestClient("http://api.hitbtc.com");
            var request1 = new RestRequest("/api/1/public/ETHUSD/ticker", Method.GET);
            request1.AddParameter("nonce", GetNonce());
            request1.AddParameter("apikey", apiKey);
            string sign1 = CalculateSignature(client1.BuildUri(request1).PathAndQuery, secretKey);
            request1.AddHeader("X-Signature", sign1);
            var response1 = client1.Execute(request1);
            VlrETH = (response1.Content);
            words1 = VlrETH.Split(separators, StringSplitOptions.RemoveEmptyEntries);
            double vlrPesos1 = Convert.ToDouble(words1[3].Replace(".", ","));
            vlrPesos1 = vlrPesos1 * VlrDolar;
            string EnDolares = words1[3];
            //dtGCSV.Rows.Add("Ethereum", "1", words1[3], vlrPesos1.ToString());
            //----------------------------------------------------------------------------
            //Obtener el valor del Ethereum al día BTC
            var client1B = new RestClient("http://api.hitbtc.com");
            var request1B = new RestRequest("/api/1/public/ETHBTC/ticker", Method.GET);
            request1.AddParameter("nonce", GetNonce());
            request1.AddParameter("apikey", apiKey);
            string sign1B = CalculateSignature(client1B.BuildUri(request1).PathAndQuery, secretKey);
            request1.AddHeader("X-Signature", sign1B);
            var response1B = client1.Execute(request1B);
            VlrETH = (response1B.Content);
            words1 = VlrETH.Split(separators, StringSplitOptions.RemoveEmptyEntries);
            decimal vlrPesos1B = Convert.ToDecimal(words1[3].Replace(".", ","));
            //vlrPesos1 = vlrPesos1 * VlrDolar;
            img = new Bitmap(ruta + "\\resources\\ethereum_16.png");
            dtGCSV.Rows.Add(img,"Ethereum", vlrPesos1B.ToString(), EnDolares, vlrPesos1.ToString());
            //----------------------------------------------------------------------------

            //Obtener el valor del Litecoin al día USD-COP
            var client2 = new RestClient("http://api.hitbtc.com");
            var request2 = new RestRequest("/api/1/public/LTCUSD/ticker", Method.GET);
            request2.AddParameter("nonce", GetNonce());
            request2.AddParameter("apikey", apiKey);
            string sign2 = CalculateSignature(client2.BuildUri(request2).PathAndQuery, secretKey);
            request2.AddHeader("X-Signature", sign2);
            var response2 = client2.Execute(request2);
            vlrLtc = (response2.Content);
            words2 = vlrLtc.Split(separators, StringSplitOptions.RemoveEmptyEntries);
            double vlrPesos2 = Convert.ToDouble(words2[3].Replace(".", ","));
            vlrPesos2 = vlrPesos2 * VlrDolar;
            string EnDolaresLtc = words2[3];
            //dtGCSV.Rows.Add("Litecoin", "1", words2[3], string.Format("{0:#.00}", vlrPesos2.ToString()));
            //----------------------------------------------------------------------------
            //Obtener el valor del Litecoin al día BTC
            var client2B = new RestClient("http://api.hitbtc.com");
            var request2B = new RestRequest("/api/1/public/LTCBTC/ticker", Method.GET);
            request2.AddParameter("nonce", GetNonce());
            request2.AddParameter("apikey", apiKey);
            string sign2B = CalculateSignature(client2.BuildUri(request2).PathAndQuery, secretKey);
            request2.AddHeader("X-Signature", sign2);
            var response2B = client2.Execute(request2B);
            vlrLtc = (response2B.Content);
            words2 = vlrLtc.Split(separators, StringSplitOptions.RemoveEmptyEntries);
            decimal vlrPesos2B = Convert.ToDecimal(words2[3].Replace(".", ","));
            //vlrPesos2 = vlrPesos2 * VlrDolar;
            img = new Bitmap(ruta + "\\resources\\litecoin_16.png");
            dtGCSV.Rows.Add(img, "Litecoin", vlrPesos2B.ToString(), EnDolaresLtc, vlrPesos2.ToString());
            //----------------------------------------------------------------------------
            //Obtener el valor del Ripple al día USD-COP
            var client3 = new RestClient("http://api.hitbtc.com");
            var request3 = new RestRequest("/api/1/public/XRPUSDT/ticker", Method.GET);
            request3.AddParameter("nonce", GetNonce());
            request3.AddParameter("apikey", apiKey);
            string sign3 = CalculateSignature(client3.BuildUri(request3).PathAndQuery, secretKey);
            request3.AddHeader("X-Signature", sign3);
            var response3 = client3.Execute(request3);
            vlrXRP = (response3.Content);
            words3 = vlrXRP.Split(separators, StringSplitOptions.RemoveEmptyEntries);
            double vlrPesos3 = Convert.ToDouble(words3[3].Replace(".", ","));
            vlrPesos3 = vlrPesos3 * VlrDolar;
            string EnDolaresxrp = words3[3];
            //dtGCSV.Rows.Add("Ripple", "1", words3[3], string.Format("{0:#.00}", vlrPesos3.ToString()));
            //----------------------------------------------------------------------------
            //Obtener el valor del Ripple al día BTC
            var client3B = new RestClient("http://api.hitbtc.com");
            var request3B = new RestRequest("/api/1/public/XRPBTC/ticker", Method.GET);
            request3.AddParameter("nonce", GetNonce());
            request3.AddParameter("apikey", apiKey);
            string sign3B = CalculateSignature(client3B.BuildUri(request3).PathAndQuery, secretKey);
            request3B.AddHeader("X-Signature", sign3B);
            var response3B = client3.Execute(request3B);
            vlrXRP = (response3B.Content);
            words3 = vlrXRP.Split(separators, StringSplitOptions.RemoveEmptyEntries);
            decimal vlrPesos3B = Convert.ToDecimal(words3[3].Replace(".", ","));
            //vlrPesos3 = vlrPesos3 * VlrDolar;
            img = new Bitmap(ruta + "\\resources\\ripple_16.png");
            dtGCSV.Rows.Add(img, "Ripple", vlrPesos3B.ToString(), EnDolaresxrp, vlrPesos3.ToString());
            //----------------------------------------------------------------------------
            //Obtener el valor del Digibyte al día USD-COP
            var client4 = new RestClient("http://api.hitbtc.com");
            var request4 = new RestRequest("/api/1/public/DGBUSD/ticker", Method.GET);
            request4.AddParameter("nonce", GetNonce());
            request4.AddParameter("apikey", apiKey);
            string sign4 = CalculateSignature(client4.BuildUri(request4).PathAndQuery, secretKey);
            request4.AddHeader("X-Signature", sign4);
            var response4 = client4.Execute(request4);
            vlrDGB = (response4.Content);
            words4 = vlrDGB.Split(separators, StringSplitOptions.RemoveEmptyEntries);
            double vlrPesos4 = Convert.ToDouble(words4[3].Replace(".", ","));
            vlrPesos4 = vlrPesos4 * VlrDolar;
            string EnDolaresDGB = words4[3];
            //dtGCSV.Rows.Add("Digibyte", "1", words4[3], string.Format("{0:$###,##0.00}", vlrPesos4.ToString()));
            //----------------------------------------------------------------------------
            //Obtener el valor del Digibyte al día BTC
            var client4B = new RestClient("http://api.hitbtc.com");
            var request4B = new RestRequest("/api/1/public/DGBBTC/ticker", Method.GET);
            request4.AddParameter("nonce", GetNonce());
            request4.AddParameter("apikey", apiKey);
            string sign4B = CalculateSignature(client4B.BuildUri(request4B).PathAndQuery, secretKey);
            request4B.AddHeader("X-Signature", sign4B);
            var response4B = client4.Execute(request4B);
            vlrDGB = (response4B.Content);
            words4 = vlrDGB.Split(separators, StringSplitOptions.RemoveEmptyEntries);
            decimal vlrPesos4B = Convert.ToDecimal(words4[3].Replace(".", ","));
            //vlrPesos4 = vlrPesos4 * VlrDolar;
            img = new Bitmap(ruta + "\\resources\\digibyte_16.png");
            dtGCSV.Rows.Add(img,"Digibyte", vlrPesos4B.ToString(), EnDolaresDGB, vlrPesos4.ToString());
            //----------------------------------------------------------------------------
            //Obtener el valor del Dash al día USD-COP
            var client5 = new RestClient("http://api.hitbtc.com");
            var request5 = new RestRequest("/api/1/public/DASHUSD/ticker", Method.GET);
            request5.AddParameter("nonce", GetNonce());
            request5.AddParameter("apikey", apiKey);
            string sign5 = CalculateSignature(client5.BuildUri(request5).PathAndQuery, secretKey);
            request5.AddHeader("X-Signature", sign5);
            var response5 = client5.Execute(request5);
            vlrPIVX = (response5.Content);
            words5 = vlrPIVX.Split(separators, StringSplitOptions.RemoveEmptyEntries);
            double vlrPesos5 = Convert.ToDouble(words5[3].Replace(".", ","));
            vlrPesos5 = vlrPesos5 * VlrDolar;
            string EnDolaresDash = words5[3];
            //dtGCSV.Rows.Add("Dash", "1", words5[3], string.Format("{0:$###,##0.00}", vlrPesos5.ToString()));
            //----------------------------------------------------------------------------
            //Obtener el valor del Dash al día BTC
            var client5B = new RestClient("http://api.hitbtc.com");
            var request5B = new RestRequest("/api/1/public/DASHBTC/ticker", Method.GET);
            request5.AddParameter("nonce", GetNonce());
            request5.AddParameter("apikey", apiKey);
            string sign5B = CalculateSignature(client5.BuildUri(request5).PathAndQuery, secretKey);
            request5B.AddHeader("X-Signature", sign5B);
            var response5B = client5.Execute(request5B);
            vlrPIVX = (response5B.Content);
            words5 = vlrPIVX.Split(separators, StringSplitOptions.RemoveEmptyEntries);
            decimal vlrPesos5B = Convert.ToDecimal(words5[3].Replace(".", ","));
            //vlrPesos5 = vlrPesos5 * VlrDolar;
            img = new Bitmap(ruta + "\\resources\\dash_16.png");
            dtGCSV.Rows.Add(img, "Dash", vlrPesos5B.ToString(), EnDolaresDash, vlrPesos5.ToString());
            //----------------------------------------------------------------------------
            //Obtener el valor del Bytecoin al día
            var client6 = new RestClient("http://api.hitbtc.com");
            var request6 = new RestRequest("/api/1/payment/transactions?limit=50", Method.GET);
            request6.AddParameter("nonce", GetNonce());
            request6.AddParameter("apikey", apiKey);
            string sign6 = CalculateSignature(client6.BuildUri(request6).PathAndQuery, secretKey);
            request6.AddHeader("X-Signature", sign6);
            var response6 = client6.Execute(request6);
            vlrBCN = (response6.Content);
            //txtResult.Text = vlrBCN.ToString();
            ////words6 = vlrBCN.Split(separators, StringSplitOptions.RemoveEmptyEntries);
            ////double vlrPesos6 = Convert.ToDouble(words6[3].Replace(".", ","));
            ////vlrPesos6 = vlrPesos6 * VlrDolar;
            ////dtGCSV.Rows.Add("Bytecoin", "0.0000", words6[3], string.Format("{0:$###,##0.00}", vlrPesos6.ToString()));
            //////----------------------------------------------------------------------------

            //ObtenerMonedaBTC_COP_USD("XRP");

            /// "/api/1/payment/balance", Method.GET  -> Balance de HitBTC
            /// "/api/1/payment/address/BTC", Method.GET -> Dirección de BTC o cualquier otra billetera
            /// "/api/1/payment/transactions?limit=50", Method.GET -> Historico Tx
            /// 
            rtxtLog.Text = rtxtLog.Text + "\r" + newFecha.ToString() + " - " + "Valores de monedas obtenidos...OK";
        }

        public static double suma(double x, double y)
        {
            return (x + y);
            
        }

        public void msgVentana()
        {
            this.Text = this.Text + sumidero.estrategiaActiva;
        }

        public static string ObtenerMonedaBTC_COP_USD(string cryptocurrency)
        {
           // const string apiKey = "26dd38504e39df9241e8d9860062af22";
            //const string secretKey = "f908c5ba21775e87865d2ef035fb8282";

            char[] separators = { ',', '!', '?', ';', ':', ' ', '{', '}', '"' };
            string[] words;
            //string[] cadena;
            double VlrDolar = 3016.2;
            var cadena = "";
            string EnDolar = "";

            //Obtener el valor del cryptomoneda al día...
            var client6 = new RestClient("http://api.hitbtc.com");
            
            switch (cryptocurrency)
            {
                case "BTC":
                    EnDolar = "/api/1/public/BTCUSD/ticker";
                    break;
                case "ETH":
                    EnDolar = "/api/1/public/ETHUSD/ticker";
                    break;
                case "LTC":
                    EnDolar = "/api/1/public/LTCUSD/ticker";
                    break;
                case "XRP":
                    EnDolar = "/api/1/public/XRPUSD/ticker";
                    break;
                case "DASH":
                    EnDolar = "/api/1/public/DASHUSD/ticker";
                    break;
                case "DGB":
                    EnDolar = "/api/1/public/DGBUSD/ticker";
                    break;
                default:
                    break;
            }
            // Verificar la asignación de la variable...
            //var request6 = new RestRequest(EnDolar, Method.GET);
            //////var request6 = new RestRequest("/api/1/public/DGBUSD/ticker", Method.GET);
            //////request6.AddParameter("nonce", GetNonce());
            //////request6.AddParameter("apikey", apiKey);
            //////string sign6 = CalculateSignature(client6.BuildUri(request6).PathAndQuery, secretKey);
            //////request6.AddHeader("X-Signature", sign6);
            //////var response6 = client6.Execute(request6);
            //////cadena = (response6.Content);
            //////words= cadena.Split(separators, StringSplitOptions.RemoveEmptyEntries);
            //////double vlrPesos6 = Convert.ToDouble(words[3].Replace(".", ","));
            //////vlrPesos6 = vlrPesos6 * VlrDolar;
            ////////dtGCSV.Rows.Add("Bytecoin", "1", words[3], string.Format("{0:$###,##0.00}", vlrPesos6.ToString()));
            return (cadena);
        }

        private void ayudaToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void acercaDeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Hexocoin S.A.S." + "\r" + "Programó: Julián Galeano");
        }

        private void salirToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void otroToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void frmPpal_Load(object sender, EventArgs e)
        {
            EstadoBot.Text = "Bot Detenido!";
            toolStripStatusLabel1.Text = "Iniciando aplicación...";
            rtxtLog.Text = rtxtLog.Text + "\r" + (newFecha.ToString() + " - " + "Iniciación de aplicación");
            toolStripStatusLabel1.Text = "Cargando configuración...";
            toolStripStatusLabel1.Text = "Cargando logos de criptodivisas...";
            LoadCurrencyLogos();
            rtxtLog.Text = rtxtLog.Text + "\r" + (newFecha.ToString() + " - " + "Logos de criptodivisas cargados...OK");
            toolStripStatusLabel1.Text = "Logos de criptodivisas cargados...OK";
            toolStripStatusLabel1.Text = "Cargando Claves...";
            LoadAPIKeys();
            newFecha = DateTime.Now;
            rtxtLog.Text = rtxtLog.Text + "\r" + (newFecha.ToString() + " - " + "Claves leídas...");
            toolStripStatusLabel1.Text = "Claves cargadas...OK";
            toolStripStatusLabel1.Text = "Cargando Histórico de portafolio...";
            //Cargar portafolio local con fechas...
            toolStripStatusLabel1.Text = "Accediendo a portafolio en HITBTC...";
            //Consumir servicio web para portafolio actual..
            toolStripStatusLabel1.Text = "Incialización completa";
            EstadoBot.Text = "Bot Detenido!";
            toolStripStatusLabel1.Text = "Actualizando gráfica de monedas";
            toolStripStatusLabel1.Text = "OK";
            rtxtLog.Text = rtxtLog.Text + "\r" + (newFecha.ToString() + " - " + "Verificando conexión a Internet...");
            MostrarHistorial();

            bool Conectado = CheckForInternetConnection();
                if (Conectado == true)
                {
                    picConectado.ImageLocation = (ruta + "\\resources\\connected.png");
                    picConectado.BackColor = Color.Lime;
                recuest();
                WBS_AltCoins();
                }
                else
                {
                    picConectado.ImageLocation = (ruta + "\\resources\\disconnected.png");
                    picConectado.BackColor = Color.Red;
                }
            rtxtLog.Text = rtxtLog.Text + "\r" + (newFecha.ToString() + " - " + "Cargando alarmas...");            
            CargarAlarmas();
            CargarRNA();            
            lblvalordolar.ImageLocation = (ruta + "\\resources\\APPL.png");

        }

        //Cargar los logos de las monedas..
        public void LoadCurrencyLogos()
        {
            //Actualizar las monedas más significativas
            picBTCbtc.ImageLocation = (ruta + "\\resources\\bitcoin.png");
            picBTCusd.ImageLocation = (ruta + "\\resources\\usa.png");
            picBTCcop.ImageLocation = (ruta + "\\resources\\cop.png");
            //picBTC.ImageLocation = (ruta + "\\resources\\bitcoin.png");
            //picETH.ImageLocation = (ruta + "\\resources\\ethereum.png");
            //picLTC.ImageLocation = (ruta + "\\resources\\litecoin.png");
            //picXRP.ImageLocation = (ruta + "\\resources\\ripple.png");
            //picDGB.ImageLocation = (ruta + "\\resources\\digibyte.png");
            //picPIVX.ImageLocation = (ruta + "\\resources\\pivx.png");
            //picDash.ImageLocation = (ruta + "\\resources\\dash.png");
            //picBCN.ImageLocation = (ruta + "\\resources\\bytecoin.png");
            //--------------------------------------------------------
        }

        public void LoadAPIKeys()
        {
            counter = 0;
            System.IO.StreamReader file = new System.IO.StreamReader( ruta + @"\keys.txt");
            while ((line = file.ReadLine()) != null)
            {
                if (counter == 0)
                {
                    apiKey = line;
                }
                else
                {
                    secretKey = line;
                }                
                counter++;
            }
            file.Close();
        }
        public void CargarAlarmas()
        {
            //Limpiar arreglo de Alarmas
            dtAlarmas.Rows.Clear();
            string[] words;
            char[] separators = { ',', '!', '?', ';', ':', ' ', '{', '}', '"' };
            // Cargar archivo de alarmas fijadas por el usuario
            System.IO.StreamReader file = new System.IO.StreamReader(ruta + @"\alarmas.txt");
            while ((line = file.ReadLine()) != null)
            {
                {
                    words = line.Split(separators, StringSplitOptions.RemoveEmptyEntries);
                    dtAlarmas.Rows.Add(words[0], words[1], words[2], words[3], words[4], words[5], words[6], words[7]);
                }
            }
            file.Close();
            rtxtLog.Text = rtxtLog.Text + "\r" + newFecha.ToString() + " - " + "Configuración de alarmas...OK";

            //Traer gráficas de CoinMarketCap de comportamiento de monedas.
            piBTC.ImageLocation = (@"https://s2.coinmarketcap.com/generated/sparklines/web/7d/usd/1.png");
            picCrypto1.ImageLocation = (@"https://s2.coinmarketcap.com/generated/sparklines/web/7d/usd/1027.png");
            picCrypto2.ImageLocation = (@"https://s2.coinmarketcap.com/generated/sparklines/web/7d/usd/2.png");
            picCrypto3.ImageLocation = (@"https://s2.coinmarketcap.com/generated/sparklines/web/7d/usd/52.png");
            picCrypto4.ImageLocation = (@"https://s2.coinmarketcap.com/generated/sparklines/web/7d/usd/109.png");
            picCrypto5.ImageLocation = (@"https://s2.coinmarketcap.com/generated/sparklines/web/7d/usd/372.png");
        }

        public void CargarRNA()
        {
            //Cargar valores para la RNA - Red Neuronal Artificial Compra/Venta
            //Variables para la red neuronal
            int counter = 0;
            string line;
            string ruta = Application.StartupPath;
            System.IO.StreamReader file = new System.IO.StreamReader(ruta + @"\config\RNA_compra.txt");
            while ((line = file.ReadLine()) != null)
            {
                String[] words3;
                words3 = line.Split(',');

                switch (words3[0])
                {
                    case "m1_com":
                        RNA_m1_compra = Convert.ToDouble(words3[1]);
                        break;
                    case "m5_com":
                        RNA_m5_compra = Convert.ToDouble(words3[1]);
                        break;
                    case "m15_com":
                        RNA_m15_compra = Convert.ToDouble(words3[1]);
                        break;
                    case "m30_com":
                        RNA_m30_compra = Convert.ToDouble(words3[1]);
                        break;
                    case "SAR_com":
                        RNA_SAR_compra = Convert.ToDouble(words3[1]);
                        break;
                    case "MACD_com":
                        RNA_MACD_compra = Convert.ToDouble(words3[1]);
                        break;
                    case "RSI_com":
                        RNA_RSI_compra = Convert.ToDouble(words3[1]);
                        break;
                    case "EMA_com":
                        RNA_EMA_compra = Convert.ToDouble(words3[1]);
                        break;
                    default:
                        break;
                }

                counter++;
            }
            file.Close();
            //Lectura del archivo de configuración para VENTA
            System.IO.StreamReader file2 = new System.IO.StreamReader(ruta + @"\config\RNA_venta.txt");
            while ((line = file2.ReadLine()) != null)
            {
                String[] words3;
                words3 = line.Split(',');

                switch (words3[0])
                {
                    case "m1_vta":
                        RNA_m1_venta = Convert.ToDouble(words3[1]);
                        break;
                    case "m5_vta":
                        RNA_m5_venta = Convert.ToDouble(words3[1]);
                        break;
                    case "m15_vta":
                        RNA_m15_venta = Convert.ToDouble(words3[1]);
                        break;
                    case "m30_vta":
                        RNA_m30_venta = Convert.ToDouble(words3[1]);
                        break;
                    case "SAR_vta":
                        RNA_SAR_venta = Convert.ToDouble(words3[1]);
                        break;
                    case "MACD_vta":
                        RNA_MACD_venta = Convert.ToDouble(words3[1]);
                        break;
                    case "RSI_vta":
                        RNA_RSI_venta = Convert.ToDouble(words3[1]);
                        break;
                    case "EMA_vta":
                        RNA_EMA_venta = Convert.ToDouble(words3[1]);
                        break;
                    default:
                        break;
                }

                counter++;
            }
            file.Close();  

    }


        private void configuraciónAPIKeyToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmApiKeys ConfigKey = new frmApiKeys();
            ConfigKey.Show();
        }

        public static string recuest()
        {
            HttpWebRequest peticion = (HttpWebRequest)WebRequest.Create("http://www.elcolombiano.com");
            HttpWebResponse respuesta = (HttpWebResponse)peticion.GetResponse();
            string html = new StreamReader(respuesta.GetResponseStream()).ReadToEnd();

            string aBuscar = "<div class=\"indicador\"> <h5>DOLAR</h5> <span> $";

            int i = html.IndexOf(aBuscar, StringComparison.InvariantCultureIgnoreCase);
            i += aBuscar.Length;
            int f = html.IndexOf("\r", i, StringComparison.InvariantCultureIgnoreCase);

            string str = html.Substring(i, f - i);

            Console.WriteLine(str);
            return (str);
        }

        private void activarBotToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (activarBotToolStripMenuItem.Text  == "Activar Bot")
            {
                EstadoBot.Text = "Bot Activado!";
               // AssestHitBTC.BackColor = Color.LightGreen;
                EstadoBot.BackColor = Color.Green;
                activarBotToolStripMenuItem.Text = "Detener Bot";
                newFecha = DateTime.Now;
                rtxtLog.Text = rtxtLog.Text + "\r" + newFecha.ToString() + " - " + "Robot Activado por usuario.";
                //Habilitar Reloj
                tmrALT.Enabled = true;
                WBS_dolar();
                DateTime tiempoinicial = DateTime.Now;
                //WBS_Porfolio(Ini);
                string msg = "Inicio de Robot" + "-" + tiempoinicial.ToString();
                LogBitacora(msg);
                txtVlrDolar.Text = recuest();
                WBS_AltCoins();
            }
            else
            {
                EstadoBot.Text = "Bot Detenido!";
                //gpAssestHitBTC.BackColor = Color.LightGray;
                EstadoBot.BackColor = Color.Gray;
                activarBotToolStripMenuItem.Text = "Activar Bot";
                newFecha = DateTime.Now;
                //Habilitar Reloj
                tmrALT.Enabled = false;
                DateTime tiempofinal = DateTime.Now;
                TimeSpan total = new TimeSpan(tiempofinal.Ticks - tiempoinicial.Ticks);
                //MessageBox.Show(total.ToString());                
                //WBS_Portfolio(Fin);
                string msg = "Robot detenido" + "-" + tiempofinal.ToString();
                rtxtLog.Text = rtxtLog.Text + "\r" + newFecha.ToString() + " - " + "Robot Detenido por usuario:" + msg;
                LogBitacora(msg);
                msg = "Tiempo de ejecución:" + total.ToString();
                LogBitacora(msg);
            }

        }

        private void EstadoBot_Click(object sender, EventArgs e)
        { ///**** CODIGO REDUNDANTE  ***
            if (activarBotToolStripMenuItem.Text == "Activar Bot")
            {
                EstadoBot.Text = "Bot Activado!";
                //gpAssestHitBTC.BackColor = Color.LightGreen;
                EstadoBot.BackColor = Color.Green;
                activarBotToolStripMenuItem.Text = "Detener Bot";
                newFecha = DateTime.Now;
                rtxtLog.Text = rtxtLog.Text + "\r" + newFecha.ToString() + " - " + "Robot Activado por usuario.";
            }
            else
            {
                EstadoBot.Text = "Bot Detenido!";
               // gpAssestHitBTC.BackColor = Color.LightGray;
                EstadoBot.BackColor = Color.Gray;
                activarBotToolStripMenuItem.Text = "Activar Bot";
                newFecha = DateTime.Now;
                rtxtLog.Text = rtxtLog.Text + "\r" + newFecha.ToString() + " - " + "Robot Detenido por usuario.";
            }

        }

        private void btnupdate_Click(object sender, EventArgs e)
        {
            
            dtOHLC.Rows.Clear();
            //Obtener velas a 30 minutos de Ethereum
            var client = new RestClient("http://api.hitbtc.com");
            var request = new RestRequest("/api/2/public/candles/ETHBTC?period=M30", Method.GET);
            request.AddParameter("nonce", GetNonce());
            request.AddParameter("apikey", apiKey);
            string sign = CalculateSignature(client.BuildUri(request).PathAndQuery, secretKey);
            request.AddHeader("X-Signature", sign);
            var response = client.Execute(request);
            string Velas = (response.Content);
            String[] words2;
            char[] separators = {',','!', '?', ';', ' ', '{', '}', '"','[', ']'};
            String LnGrid = "";

            string tmp;
            String[] words3;

            words2 = Velas.Split(',');
            int contLn = 0;
            String open = "";
            String high = "";
            String close = "";
            String low = "";
            String volume = "";
            var timestamp = "00/00/0000";
            string ruta = Application.StartupPath;
            string path = ruta + @"\Candle.txt";

            for (int i = 0; i < words2.Length; i++)
            {
                tmp = words2[i];
                words3 = tmp.Split(separators, StringSplitOptions.RemoveEmptyEntries);
                switch (words3[0])
                {
                    case "timestamp":
                        
                        if (contLn > 0)
                        {
                            dtOHLC.Rows.Add(contLn, timestamp, open,close,high,low,volume);
                            LnGrid = "";
                            string createText = contLn +"\t"+ timestamp + "\t" + open + "\t" + close + "\t" + high + "\t" + low + "\t" + volume +"\n";
                            File.AppendAllText(path, createText);
                        }
                        contLn++;
                        timestamp = words3[2];

                        break;

                    case "open":
                        open = words3[2];
                        //LnGrid = words3[2];                    
                        break;

                    case "close":
                        close = words3[2];
                        break;

                    case "max":
                        high = words3[2];
                        break;

                    case "min":
                        low = words3[2];
                        break;
                    case "volume":
                        volume = words3[2];
                        break;

                    default:
                        //LnGrid = LnGrid + words3[2] + ",";
                        
                        break;
                }
            }
            candle.Update();

            int rowcount = dtOHLC.RowCount - 1;
            double OpenC, HighC, CloseC, LowC , volumeC = 0;
            //Por ahora 10 velas - todas: rowcount
            ////for (int i = 0; i < 4; i++)
            ////{
            ////    OpenC = Convert.ToDouble(dtOHLC.Rows[i].Cells[2].Value);
            ////    HighC = Convert.ToDouble(dtOHLC.Rows[i].Cells[3].Value);
            ////    CloseC = Convert.ToDouble(dtOHLC.Rows[i].Cells[4].Value);
            ////    LowC = Convert.ToDouble(dtOHLC.Rows[i].Cells[5].Value);
            ////    volumeC = Convert.ToDouble(dtOHLC.Rows[i].Cells[6].Value);

            ////    candle.Series["Diario"].Points.Add(OpenC, HighC, CloseC, LowC, volumeC);
            ////    //
            ////}
            ///candle.DataManipulator.FinancialFormula(FinancialFormula.ExponentialMovingAverage, "20", "Series1:Y2", "Series2:Y");
            //candle.SaveImage(Application.StartupPath + "\\candles\\LTC_BTC-M5.jpg", System.Windows.Forms.DataVisualization.Charting.ChartImageFormat.Png);

            /// Unir todas las posiciones de un vector con un separador ( y puede ser vacio)
            ////words2 = Velas.Split(separators, StringSplitOptions.RemoveEmptyEntries);
            ////String sep = ",";            
            ////LnGrid = string.Join(sep, words2);
            ////words2 = LnGrid.Split(',');

        }

        private void toolStripStatusLabel1_Click(object sender, EventArgs e)
        {

        }

        private void dtOHLC_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void txtVlrDolar_TextChanged(object sender, EventArgs e)
        {
           // VlrDolar = Convert.ToDouble(txtVlrDolar.Text);
        }

        private void tmrALT_Tick(object sender, EventArgs e)
        {
            this.Text = "HexoBOT -" + sumidero.estrategiaActiva;
            CallDolar++;
            newFecha = DateTime.Now;
            //rtxtLog.Text = rtxtLog.Text + "\r" + newFecha.ToString() + " - " + "Verificación de Perceptrón";
            bool Conectado = CheckForInternetConnection();
            if (Conectado == true)
            {
                picConectado.ImageLocation = (ruta + "\\resources\\connected.png");
                picConectado.BackColor = Color.Lime;
                if ( CallDolar >= 180)  //Verificar cada Hora el USDT - Confrontar 
                {
                    WBS_dolar();
                    LogBitacora("Obtener valor del Dolar.");
                    CallDolar = 0;
                }

                WBS_AltCoins();
            }
            else
            {
                picConectado.ImageLocation = (ruta + "\\resources\\disconnected.png");
                picConectado.BackColor = Color.Red;
                System.Media.SoundPlayer player = new System.Media.SoundPlayer(ruta + @"\resources\dial-up-modem-02.wav");
                player.Play();
            }
            
        }

        public static bool CheckForInternetConnection()
        {
            try
            {
                using (var client = new System.Net.WebClient())
                {
                    using (client.OpenRead("http://clients3.google.com/generate_204"))
                    {
                        return true;
                    }
                }
            }
            catch
            {
                return false;
            }
        }

        public void LogBitacora(string Mensaje)
        {
            string path2 = ruta + @"\log\Bitacora.txt";
            string debugText = "\n" + DateTime.Now.ToString() + ":" + Mensaje.ToString();
            File.AppendAllText(path2, debugText);

        }
        private void picConectado_Click(object sender, EventArgs e)
        {
            bool Conectado = CheckForInternetConnection();
            if (Conectado == true)
            {
                picConectado.ImageLocation = (ruta + "\\resources\\connected.png");
                picConectado.BackColor = Color.Lime;
            }
            else
            {
                picConectado.ImageLocation = (ruta + "\\resources\\disconnected.png");
                picConectado.BackColor = Color.Red;

            }
        }
        public void TiempoEjecucion()
        {
            DateTime tiempoinicial = DateTime.Now;
            DateTime tiempofinal = DateTime.Now;
            TimeSpan total = new TimeSpan(tiempofinal.Ticks - tiempoinicial.Ticks);
            MessageBox.Show(total.ToString());
        }
        private void reglasDeDistribuciónToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmDistribRules Reglas = new frmDistribRules();
            Reglas.Show();
        }

        private void redNeuronalToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmNeuralNet RDD = new frmNeuralNet();
            RDD.Show();
        }

        private void configuraciónToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmEstrategias estrategia = new frmEstrategias();
            estrategia.Show();
        }

        private void editorToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmEditorEstrategia EditorEstrategias = new frmEditorEstrategia();
            EditorEstrategias.Show();
        }

        private void btnLog_Click(object sender, EventArgs e)
        {
            ProcessStartInfo startInfo = new ProcessStartInfo();
            Process.Start("notepad.exe", ruta + "\\Log\\logErrors.txt");
        }

        private void btnBitacora_Click(object sender, EventArgs e)
        {
            ProcessStartInfo startInfo = new ProcessStartInfo();
            Process.Start("notepad.exe", ruta + "\\Log\\Bitacora.txt");
        }

        private void btnTxHistory_Click(object sender, EventArgs e)
        {
            ProcessStartInfo startInfo = new ProcessStartInfo();
            startInfo.CreateNoWindow.ToString();
            startInfo.FileName = ruta + "\\getTradeHistory.lnk";
            startInfo.Arguments = f;
            Process.Start(startInfo);
            Application.DoEvents();            
            Process.Start("notepad.exe", ruta + "\\tradeHistory.txt");
            

        }


        private void MostrarHistorial()
        {

            string line;
            String[] palabra;
            String[] words3;
            char[] separators = { ',', '[', ']', '"', ' ', '{', '}' };
            string separar;
            String remplace;



            System.IO.StreamReader file = new System.IO.StreamReader(ruta + "\\tradeHistory.txt");
            while ((line = file.ReadLine()) != null)
            {
                palabra = line.Split(',');
                remplace = line.Replace("}", "}\n");
                words3 = line.Split(separators, StringSplitOptions.RemoveEmptyEntries);
                DgvHistorial.Rows.Add(words3[2], words3[4], words3[7], words3[10], words3[13], words3[16], words3[19], words3[22]);
            }
        }
    }
}
