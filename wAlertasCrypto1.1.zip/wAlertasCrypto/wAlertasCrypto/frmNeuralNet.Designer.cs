﻿namespace wAlertasCrypto
{
    partial class frmNeuralNet
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabVtaCompra = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.txtm30_com = new System.Windows.Forms.TextBox();
            this.txtm15_com = new System.Windows.Forms.TextBox();
            this.txtm5_com = new System.Windows.Forms.TextBox();
            this.txtm1_com = new System.Windows.Forms.TextBox();
            this.txtEMA_com = new System.Windows.Forms.TextBox();
            this.txtRSI_com = new System.Windows.Forms.TextBox();
            this.txtSAR_com = new System.Windows.Forms.TextBox();
            this.txtMACD_com = new System.Windows.Forms.TextBox();
            this.picRDDCompra = new System.Windows.Forms.PictureBox();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.txtM30_vta = new System.Windows.Forms.TextBox();
            this.txtM15_vta = new System.Windows.Forms.TextBox();
            this.txtM5_vta = new System.Windows.Forms.TextBox();
            this.txtM1_vta = new System.Windows.Forms.TextBox();
            this.txtEMA_vta = new System.Windows.Forms.TextBox();
            this.txtRSI_vta = new System.Windows.Forms.TextBox();
            this.txtSAR_vta = new System.Windows.Forms.TextBox();
            this.txtMACD_vta = new System.Windows.Forms.TextBox();
            this.picRDDVenta = new System.Windows.Forms.PictureBox();
            this.btnAceptar = new System.Windows.Forms.Button();
            this.btnCancelar = new System.Windows.Forms.Button();
            this.tabVtaCompra.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picRDDCompra)).BeginInit();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picRDDVenta)).BeginInit();
            this.SuspendLayout();
            // 
            // tabVtaCompra
            // 
            this.tabVtaCompra.Controls.Add(this.tabPage1);
            this.tabVtaCompra.Controls.Add(this.tabPage2);
            this.tabVtaCompra.Location = new System.Drawing.Point(23, 22);
            this.tabVtaCompra.Name = "tabVtaCompra";
            this.tabVtaCompra.SelectedIndex = 0;
            this.tabVtaCompra.Size = new System.Drawing.Size(968, 662);
            this.tabVtaCompra.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.txtm30_com);
            this.tabPage1.Controls.Add(this.txtm15_com);
            this.tabPage1.Controls.Add(this.txtm5_com);
            this.tabPage1.Controls.Add(this.txtm1_com);
            this.tabPage1.Controls.Add(this.txtEMA_com);
            this.tabPage1.Controls.Add(this.txtRSI_com);
            this.tabPage1.Controls.Add(this.txtSAR_com);
            this.tabPage1.Controls.Add(this.txtMACD_com);
            this.tabPage1.Controls.Add(this.picRDDCompra);
            this.tabPage1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabPage1.Location = new System.Drawing.Point(4, 25);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(960, 633);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Compra";
            this.tabPage1.ToolTipText = "RNN Compras";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // txtm30_com
            // 
            this.txtm30_com.Location = new System.Drawing.Point(463, 446);
            this.txtm30_com.Name = "txtm30_com";
            this.txtm30_com.Size = new System.Drawing.Size(49, 34);
            this.txtm30_com.TabIndex = 17;
            // 
            // txtm15_com
            // 
            this.txtm15_com.Location = new System.Drawing.Point(463, 342);
            this.txtm15_com.Name = "txtm15_com";
            this.txtm15_com.Size = new System.Drawing.Size(54, 34);
            this.txtm15_com.TabIndex = 16;
            // 
            // txtm5_com
            // 
            this.txtm5_com.Location = new System.Drawing.Point(465, 245);
            this.txtm5_com.Name = "txtm5_com";
            this.txtm5_com.Size = new System.Drawing.Size(56, 34);
            this.txtm5_com.TabIndex = 15;
            // 
            // txtm1_com
            // 
            this.txtm1_com.Location = new System.Drawing.Point(462, 150);
            this.txtm1_com.Name = "txtm1_com";
            this.txtm1_com.Size = new System.Drawing.Size(52, 34);
            this.txtm1_com.TabIndex = 14;
            // 
            // txtEMA_com
            // 
            this.txtEMA_com.Location = new System.Drawing.Point(151, 368);
            this.txtEMA_com.Name = "txtEMA_com";
            this.txtEMA_com.Size = new System.Drawing.Size(57, 34);
            this.txtEMA_com.TabIndex = 13;
            // 
            // txtRSI_com
            // 
            this.txtRSI_com.Location = new System.Drawing.Point(151, 286);
            this.txtRSI_com.Name = "txtRSI_com";
            this.txtRSI_com.Size = new System.Drawing.Size(54, 34);
            this.txtRSI_com.TabIndex = 12;
            // 
            // txtSAR_com
            // 
            this.txtSAR_com.Location = new System.Drawing.Point(151, 207);
            this.txtSAR_com.Name = "txtSAR_com";
            this.txtSAR_com.Size = new System.Drawing.Size(54, 34);
            this.txtSAR_com.TabIndex = 11;
            // 
            // txtMACD_com
            // 
            this.txtMACD_com.Location = new System.Drawing.Point(151, 122);
            this.txtMACD_com.Name = "txtMACD_com";
            this.txtMACD_com.Size = new System.Drawing.Size(54, 34);
            this.txtMACD_com.TabIndex = 10;
            // 
            // picRDDCompra
            // 
            this.picRDDCompra.ImageLocation = "D:\\robot\\++Desarrollos\\Bot\\wAlertasCrypto\\wAlertasCrypto\\bin\\Debug\\resources\\RDD3" +
    "_compra.png";
            this.picRDDCompra.Location = new System.Drawing.Point(6, 6);
            this.picRDDCompra.Name = "picRDDCompra";
            this.picRDDCompra.Size = new System.Drawing.Size(948, 627);
            this.picRDDCompra.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picRDDCompra.TabIndex = 0;
            this.picRDDCompra.TabStop = false;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.txtM30_vta);
            this.tabPage2.Controls.Add(this.txtM15_vta);
            this.tabPage2.Controls.Add(this.txtM5_vta);
            this.tabPage2.Controls.Add(this.txtM1_vta);
            this.tabPage2.Controls.Add(this.txtEMA_vta);
            this.tabPage2.Controls.Add(this.txtRSI_vta);
            this.tabPage2.Controls.Add(this.txtSAR_vta);
            this.tabPage2.Controls.Add(this.txtMACD_vta);
            this.tabPage2.Controls.Add(this.picRDDVenta);
            this.tabPage2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabPage2.Location = new System.Drawing.Point(4, 25);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(960, 633);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Venta";
            this.tabPage2.ToolTipText = "RNN Ventas";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // txtM30_vta
            // 
            this.txtM30_vta.Location = new System.Drawing.Point(467, 447);
            this.txtM30_vta.Name = "txtM30_vta";
            this.txtM30_vta.Size = new System.Drawing.Size(52, 30);
            this.txtM30_vta.TabIndex = 9;
            // 
            // txtM15_vta
            // 
            this.txtM15_vta.Location = new System.Drawing.Point(467, 343);
            this.txtM15_vta.Name = "txtM15_vta";
            this.txtM15_vta.Size = new System.Drawing.Size(53, 30);
            this.txtM15_vta.TabIndex = 8;
            // 
            // txtM5_vta
            // 
            this.txtM5_vta.Location = new System.Drawing.Point(467, 243);
            this.txtM5_vta.Name = "txtM5_vta";
            this.txtM5_vta.Size = new System.Drawing.Size(55, 30);
            this.txtM5_vta.TabIndex = 7;
            // 
            // txtM1_vta
            // 
            this.txtM1_vta.Location = new System.Drawing.Point(465, 151);
            this.txtM1_vta.Name = "txtM1_vta";
            this.txtM1_vta.Size = new System.Drawing.Size(55, 30);
            this.txtM1_vta.TabIndex = 6;
            // 
            // txtEMA_vta
            // 
            this.txtEMA_vta.Location = new System.Drawing.Point(155, 368);
            this.txtEMA_vta.Name = "txtEMA_vta";
            this.txtEMA_vta.Size = new System.Drawing.Size(53, 30);
            this.txtEMA_vta.TabIndex = 5;
            // 
            // txtRSI_vta
            // 
            this.txtRSI_vta.Location = new System.Drawing.Point(152, 286);
            this.txtRSI_vta.Name = "txtRSI_vta";
            this.txtRSI_vta.Size = new System.Drawing.Size(54, 30);
            this.txtRSI_vta.TabIndex = 4;
            // 
            // txtSAR_vta
            // 
            this.txtSAR_vta.Location = new System.Drawing.Point(152, 206);
            this.txtSAR_vta.Name = "txtSAR_vta";
            this.txtSAR_vta.Size = new System.Drawing.Size(53, 30);
            this.txtSAR_vta.TabIndex = 3;
            // 
            // txtMACD_vta
            // 
            this.txtMACD_vta.Location = new System.Drawing.Point(152, 120);
            this.txtMACD_vta.Name = "txtMACD_vta";
            this.txtMACD_vta.Size = new System.Drawing.Size(53, 30);
            this.txtMACD_vta.TabIndex = 2;
            // 
            // picRDDVenta
            // 
            this.picRDDVenta.ImageLocation = "D:\\robot\\++Desarrollos\\Bot\\wAlertasCrypto\\wAlertasCrypto\\bin\\Debug\\resources\\RDD3" +
    "_venta.png";
            this.picRDDVenta.Location = new System.Drawing.Point(4, 5);
            this.picRDDVenta.Name = "picRDDVenta";
            this.picRDDVenta.Size = new System.Drawing.Size(950, 627);
            this.picRDDVenta.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picRDDVenta.TabIndex = 1;
            this.picRDDVenta.TabStop = false;
            // 
            // btnAceptar
            // 
            this.btnAceptar.Location = new System.Drawing.Point(392, 700);
            this.btnAceptar.Name = "btnAceptar";
            this.btnAceptar.Size = new System.Drawing.Size(109, 34);
            this.btnAceptar.TabIndex = 1;
            this.btnAceptar.Text = "&Aceptar";
            this.btnAceptar.UseVisualStyleBackColor = true;
            this.btnAceptar.Click += new System.EventHandler(this.btnAceptar_Click);
            // 
            // btnCancelar
            // 
            this.btnCancelar.Location = new System.Drawing.Point(552, 700);
            this.btnCancelar.Name = "btnCancelar";
            this.btnCancelar.Size = new System.Drawing.Size(109, 34);
            this.btnCancelar.TabIndex = 2;
            this.btnCancelar.Text = "&Cancelar";
            this.btnCancelar.UseVisualStyleBackColor = true;
            this.btnCancelar.Click += new System.EventHandler(this.btnCancelar_Click);
            // 
            // frmNeuralNet
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.ClientSize = new System.Drawing.Size(1024, 746);
            this.Controls.Add(this.btnCancelar);
            this.Controls.Add(this.btnAceptar);
            this.Controls.Add(this.tabVtaCompra);
            this.Name = "frmNeuralNet";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Árbol de Decisiones";
            this.TopMost = true;
            this.Load += new System.EventHandler(this.frmNeuralNet_Load);
            this.tabVtaCompra.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picRDDCompra)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picRDDVenta)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabVtaCompra;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Button btnAceptar;
        private System.Windows.Forms.Button btnCancelar;
        private System.Windows.Forms.PictureBox picRDDCompra;
        private System.Windows.Forms.PictureBox picRDDVenta;
        private System.Windows.Forms.TextBox txtm30_com;
        private System.Windows.Forms.TextBox txtm15_com;
        private System.Windows.Forms.TextBox txtm5_com;
        private System.Windows.Forms.TextBox txtm1_com;
        private System.Windows.Forms.TextBox txtEMA_com;
        private System.Windows.Forms.TextBox txtRSI_com;
        private System.Windows.Forms.TextBox txtSAR_com;
        private System.Windows.Forms.TextBox txtMACD_com;
        private System.Windows.Forms.TextBox txtM30_vta;
        private System.Windows.Forms.TextBox txtM15_vta;
        private System.Windows.Forms.TextBox txtM5_vta;
        private System.Windows.Forms.TextBox txtM1_vta;
        private System.Windows.Forms.TextBox txtEMA_vta;
        private System.Windows.Forms.TextBox txtRSI_vta;
        private System.Windows.Forms.TextBox txtSAR_vta;
        private System.Windows.Forms.TextBox txtMACD_vta;
    }
}