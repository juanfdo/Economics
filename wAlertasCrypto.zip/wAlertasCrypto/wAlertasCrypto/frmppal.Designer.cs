﻿namespace wAlertasCrypto
{
    partial class frmPpal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea2 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend2 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series2 = new System.Windows.Forms.DataVisualization.Charting.Series();
            this.grCryptoCurrency = new System.Windows.Forms.GroupBox();
            this.txtVlrDolar = new System.Windows.Forms.TextBox();
            this.lblDolarvl = new System.Windows.Forms.Label();
            this.lblCrypto6 = new System.Windows.Forms.Label();
            this.lblCrypto5 = new System.Windows.Forms.Label();
            this.lblCrypto4 = new System.Windows.Forms.Label();
            this.lblCrypto3 = new System.Windows.Forms.Label();
            this.lblCrypto2 = new System.Windows.Forms.Label();
            this.lblCrypto1 = new System.Windows.Forms.Label();
            this.picCrypto5 = new System.Windows.Forms.PictureBox();
            this.picCrypto4 = new System.Windows.Forms.PictureBox();
            this.picCrypto3 = new System.Windows.Forms.PictureBox();
            this.picCrypto2 = new System.Windows.Forms.PictureBox();
            this.picCrypto1 = new System.Windows.Forms.PictureBox();
            this.piBTC = new System.Windows.Forms.PictureBox();
            this.dtGCSV = new System.Windows.Forms.DataGridView();
            this.Logo = new System.Windows.Forms.DataGridViewImageColumn();
            this.CrytoMoneda = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.BTC = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.USD = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.COP = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.picBTCbtc = new System.Windows.Forms.PictureBox();
            this.picBTCusd = new System.Windows.Forms.PictureBox();
            this.picBTCcop = new System.Windows.Forms.PictureBox();
            this.gpAssets = new System.Windows.Forms.GroupBox();
            this.tabPortfolio = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.btnGuardar = new System.Windows.Forms.Button();
            this.dtgAssets = new System.Windows.Forms.DataGridView();
            this.Fecha = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Moneda = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.inv_cant = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.inv_BTC = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.inv_USD = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.inv_cop = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.dtgAssestHitBTC = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn12 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn13 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn14 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cmdTEst = new System.Windows.Forms.Button();
            this.gpAlarmas = new System.Windows.Forms.GroupBox();
            this.dtAlarmas = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gpLog = new System.Windows.Forms.GroupBox();
            this.btnBitacora = new System.Windows.Forms.Button();
            this.btnLog = new System.Windows.Forms.Button();
            this.rtxtLog = new System.Windows.Forms.RichTextBox();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.archivoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.salirToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ayudaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.configuraciónAPIKeyToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.reglasDeDistribuciónToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.redNeuronalToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.estrategiasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.editorToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.configuraciónToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.otroToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.activarBotToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ayudaToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.acercaDeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel2 = new System.Windows.Forms.ToolStripStatusLabel();
            this.EstadoBot = new System.Windows.Forms.ToolStripStatusLabel();
            this.dtOHLC = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn15 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn20 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn16 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn17 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn18 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn19 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Volumen = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.candle = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.btnupdate = new System.Windows.Forms.Button();
            this.tmrALT = new System.Windows.Forms.Timer(this.components);
            this.tmrUSD = new System.Windows.Forms.Timer(this.components);
            this.picConectado = new System.Windows.Forms.PictureBox();
            this.lblvalordolar = new System.Windows.Forms.PictureBox();
            this.btnTxHistory = new System.Windows.Forms.Button();
            this.grCryptoCurrency.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picCrypto5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picCrypto4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picCrypto3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picCrypto2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picCrypto1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.piBTC)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dtGCSV)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBTCbtc)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBTCusd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBTCcop)).BeginInit();
            this.gpAssets.SuspendLayout();
            this.tabPortfolio.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgAssets)).BeginInit();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgAssestHitBTC)).BeginInit();
            this.gpAlarmas.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtAlarmas)).BeginInit();
            this.gpLog.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtOHLC)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.candle)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picConectado)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblvalordolar)).BeginInit();
            this.SuspendLayout();
            // 
            // grCryptoCurrency
            // 
            this.grCryptoCurrency.Controls.Add(this.txtVlrDolar);
            this.grCryptoCurrency.Controls.Add(this.lblDolarvl);
            this.grCryptoCurrency.Controls.Add(this.lblCrypto6);
            this.grCryptoCurrency.Controls.Add(this.lblCrypto5);
            this.grCryptoCurrency.Controls.Add(this.lblCrypto4);
            this.grCryptoCurrency.Controls.Add(this.lblCrypto3);
            this.grCryptoCurrency.Controls.Add(this.lblCrypto2);
            this.grCryptoCurrency.Controls.Add(this.lblCrypto1);
            this.grCryptoCurrency.Controls.Add(this.picCrypto5);
            this.grCryptoCurrency.Controls.Add(this.picCrypto4);
            this.grCryptoCurrency.Controls.Add(this.picCrypto3);
            this.grCryptoCurrency.Controls.Add(this.picCrypto2);
            this.grCryptoCurrency.Controls.Add(this.picCrypto1);
            this.grCryptoCurrency.Controls.Add(this.piBTC);
            this.grCryptoCurrency.Controls.Add(this.dtGCSV);
            this.grCryptoCurrency.Controls.Add(this.picBTCbtc);
            this.grCryptoCurrency.Controls.Add(this.picBTCusd);
            this.grCryptoCurrency.Controls.Add(this.picBTCcop);
            this.grCryptoCurrency.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grCryptoCurrency.Location = new System.Drawing.Point(12, 34);
            this.grCryptoCurrency.Name = "grCryptoCurrency";
            this.grCryptoCurrency.Size = new System.Drawing.Size(1061, 425);
            this.grCryptoCurrency.TabIndex = 1;
            this.grCryptoCurrency.TabStop = false;
            this.grCryptoCurrency.Text = "VALORES ACTUALES";
            // 
            // txtVlrDolar
            // 
            this.txtVlrDolar.Location = new System.Drawing.Point(678, 21);
            this.txtVlrDolar.Name = "txtVlrDolar";
            this.txtVlrDolar.Size = new System.Drawing.Size(92, 22);
            this.txtVlrDolar.TabIndex = 56;
            this.txtVlrDolar.TextChanged += new System.EventHandler(this.txtVlrDolar_TextChanged);
            // 
            // lblDolarvl
            // 
            this.lblDolarvl.AutoSize = true;
            this.lblDolarvl.Location = new System.Drawing.Point(675, 24);
            this.lblDolarvl.Name = "lblDolarvl";
            this.lblDolarvl.Size = new System.Drawing.Size(85, 17);
            this.lblDolarvl.TabIndex = 55;
            this.lblDolarvl.Text = "ValorDolar";
            // 
            // lblCrypto6
            // 
            this.lblCrypto6.AutoSize = true;
            this.lblCrypto6.ForeColor = System.Drawing.Color.Navy;
            this.lblCrypto6.Location = new System.Drawing.Point(900, 332);
            this.lblCrypto6.Name = "lblCrypto6";
            this.lblCrypto6.Size = new System.Drawing.Size(39, 17);
            this.lblCrypto6.TabIndex = 54;
            this.lblCrypto6.Text = "BCN";
            // 
            // lblCrypto5
            // 
            this.lblCrypto5.AutoSize = true;
            this.lblCrypto5.ForeColor = System.Drawing.Color.Navy;
            this.lblCrypto5.Location = new System.Drawing.Point(901, 279);
            this.lblCrypto5.Name = "lblCrypto5";
            this.lblCrypto5.Size = new System.Drawing.Size(41, 17);
            this.lblCrypto5.TabIndex = 53;
            this.lblCrypto5.Text = "DGB";
            // 
            // lblCrypto4
            // 
            this.lblCrypto4.AutoSize = true;
            this.lblCrypto4.ForeColor = System.Drawing.Color.Navy;
            this.lblCrypto4.Location = new System.Drawing.Point(902, 226);
            this.lblCrypto4.Name = "lblCrypto4";
            this.lblCrypto4.Size = new System.Drawing.Size(39, 17);
            this.lblCrypto4.TabIndex = 52;
            this.lblCrypto4.Text = "XRP";
            // 
            // lblCrypto3
            // 
            this.lblCrypto3.AutoSize = true;
            this.lblCrypto3.ForeColor = System.Drawing.Color.Navy;
            this.lblCrypto3.Location = new System.Drawing.Point(901, 172);
            this.lblCrypto3.Name = "lblCrypto3";
            this.lblCrypto3.Size = new System.Drawing.Size(37, 17);
            this.lblCrypto3.TabIndex = 51;
            this.lblCrypto3.Text = "LTC";
            // 
            // lblCrypto2
            // 
            this.lblCrypto2.AutoSize = true;
            this.lblCrypto2.ForeColor = System.Drawing.Color.Navy;
            this.lblCrypto2.Location = new System.Drawing.Point(901, 118);
            this.lblCrypto2.Name = "lblCrypto2";
            this.lblCrypto2.Size = new System.Drawing.Size(39, 17);
            this.lblCrypto2.TabIndex = 50;
            this.lblCrypto2.Text = "ETH";
            // 
            // lblCrypto1
            // 
            this.lblCrypto1.AutoSize = true;
            this.lblCrypto1.ForeColor = System.Drawing.Color.Navy;
            this.lblCrypto1.Location = new System.Drawing.Point(902, 67);
            this.lblCrypto1.Name = "lblCrypto1";
            this.lblCrypto1.Size = new System.Drawing.Size(38, 17);
            this.lblCrypto1.TabIndex = 49;
            this.lblCrypto1.Text = "BTC";
            // 
            // picCrypto5
            // 
            this.picCrypto5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picCrypto5.ImageLocation = "";
            this.picCrypto5.Location = new System.Drawing.Point(902, 332);
            this.picCrypto5.Name = "picCrypto5";
            this.picCrypto5.Size = new System.Drawing.Size(150, 47);
            this.picCrypto5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picCrypto5.TabIndex = 48;
            this.picCrypto5.TabStop = false;
            // 
            // picCrypto4
            // 
            this.picCrypto4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picCrypto4.ImageLocation = "";
            this.picCrypto4.Location = new System.Drawing.Point(902, 279);
            this.picCrypto4.Name = "picCrypto4";
            this.picCrypto4.Size = new System.Drawing.Size(150, 47);
            this.picCrypto4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picCrypto4.TabIndex = 47;
            this.picCrypto4.TabStop = false;
            // 
            // picCrypto3
            // 
            this.picCrypto3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picCrypto3.ImageLocation = "";
            this.picCrypto3.Location = new System.Drawing.Point(902, 226);
            this.picCrypto3.Name = "picCrypto3";
            this.picCrypto3.Size = new System.Drawing.Size(150, 47);
            this.picCrypto3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picCrypto3.TabIndex = 46;
            this.picCrypto3.TabStop = false;
            // 
            // picCrypto2
            // 
            this.picCrypto2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picCrypto2.ImageLocation = "";
            this.picCrypto2.Location = new System.Drawing.Point(902, 172);
            this.picCrypto2.Name = "picCrypto2";
            this.picCrypto2.Size = new System.Drawing.Size(150, 47);
            this.picCrypto2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picCrypto2.TabIndex = 45;
            this.picCrypto2.TabStop = false;
            // 
            // picCrypto1
            // 
            this.picCrypto1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picCrypto1.ImageLocation = "";
            this.picCrypto1.Location = new System.Drawing.Point(902, 120);
            this.picCrypto1.Name = "picCrypto1";
            this.picCrypto1.Size = new System.Drawing.Size(150, 47);
            this.picCrypto1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picCrypto1.TabIndex = 44;
            this.picCrypto1.TabStop = false;
            // 
            // piBTC
            // 
            this.piBTC.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.piBTC.ImageLocation = "";
            this.piBTC.Location = new System.Drawing.Point(902, 67);
            this.piBTC.Name = "piBTC";
            this.piBTC.Size = new System.Drawing.Size(150, 47);
            this.piBTC.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.piBTC.TabIndex = 43;
            this.piBTC.TabStop = false;
            // 
            // dtGCSV
            // 
            this.dtGCSV.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.dtGCSV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtGCSV.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Logo,
            this.CrytoMoneda,
            this.BTC,
            this.USD,
            this.COP});
            this.dtGCSV.Location = new System.Drawing.Point(6, 54);
            this.dtGCSV.Name = "dtGCSV";
            this.dtGCSV.RowTemplate.Height = 24;
            this.dtGCSV.ScrollBars = System.Windows.Forms.ScrollBars.Horizontal;
            this.dtGCSV.Size = new System.Drawing.Size(888, 362);
            this.dtGCSV.TabIndex = 31;
            // 
            // Logo
            // 
            this.Logo.Description = "Moneda";
            this.Logo.HeaderText = "Logo";
            this.Logo.Name = "Logo";
            this.Logo.ToolTipText = "Otra Moneda";
            this.Logo.Width = 50;
            // 
            // CrytoMoneda
            // 
            this.CrytoMoneda.HeaderText = "Moneda";
            this.CrytoMoneda.Name = "CrytoMoneda";
            this.CrytoMoneda.Width = 94;
            // 
            // BTC
            // 
            this.BTC.HeaderText = "BTC";
            this.BTC.Name = "BTC";
            this.BTC.ToolTipText = "Valor en Bitcoins";
            this.BTC.Width = 67;
            // 
            // USD
            // 
            this.USD.HeaderText = "USD";
            this.USD.Name = "USD";
            this.USD.ToolTipText = "Valor en Dolares";
            this.USD.Width = 69;
            // 
            // COP
            // 
            this.COP.HeaderText = "COP";
            this.COP.Name = "COP";
            this.COP.ToolTipText = "Valor en Pesos Colombianos";
            this.COP.Width = 69;
            // 
            // picBTCbtc
            // 
            this.picBTCbtc.ImageLocation = "C:\\iconos\\btc-42.png";
            this.picBTCbtc.Location = new System.Drawing.Point(423, 15);
            this.picBTCbtc.Name = "picBTCbtc";
            this.picBTCbtc.Size = new System.Drawing.Size(36, 33);
            this.picBTCbtc.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picBTCbtc.TabIndex = 19;
            this.picBTCbtc.TabStop = false;
            // 
            // picBTCusd
            // 
            this.picBTCusd.ImageLocation = "C:\\iconos\\usd.png";
            this.picBTCusd.Location = new System.Drawing.Point(612, 15);
            this.picBTCusd.Name = "picBTCusd";
            this.picBTCusd.Size = new System.Drawing.Size(36, 33);
            this.picBTCusd.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picBTCusd.TabIndex = 8;
            this.picBTCusd.TabStop = false;
            // 
            // picBTCcop
            // 
            this.picBTCcop.ImageLocation = "C:\\iconos\\cop.png";
            this.picBTCcop.Location = new System.Drawing.Point(817, 15);
            this.picBTCcop.Name = "picBTCcop";
            this.picBTCcop.Size = new System.Drawing.Size(36, 33);
            this.picBTCcop.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picBTCcop.TabIndex = 7;
            this.picBTCcop.TabStop = false;
            // 
            // gpAssets
            // 
            this.gpAssets.Controls.Add(this.tabPortfolio);
            this.gpAssets.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gpAssets.Location = new System.Drawing.Point(12, 459);
            this.gpAssets.Name = "gpAssets";
            this.gpAssets.Size = new System.Drawing.Size(832, 291);
            this.gpAssets.TabIndex = 2;
            this.gpAssets.TabStop = false;
            this.gpAssets.Text = "Assets";
            // 
            // tabPortfolio
            // 
            this.tabPortfolio.Controls.Add(this.tabPage1);
            this.tabPortfolio.Controls.Add(this.tabPage2);
            this.tabPortfolio.Location = new System.Drawing.Point(17, 21);
            this.tabPortfolio.Name = "tabPortfolio";
            this.tabPortfolio.SelectedIndex = 0;
            this.tabPortfolio.Size = new System.Drawing.Size(797, 264);
            this.tabPortfolio.TabIndex = 2;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.btnGuardar);
            this.tabPage1.Controls.Add(this.dtgAssets);
            this.tabPage1.Location = new System.Drawing.Point(4, 25);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(789, 235);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Registros";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // btnGuardar
            // 
            this.btnGuardar.Location = new System.Drawing.Point(3, 0);
            this.btnGuardar.Name = "btnGuardar";
            this.btnGuardar.Size = new System.Drawing.Size(79, 30);
            this.btnGuardar.TabIndex = 3;
            this.btnGuardar.Text = "Guardar";
            this.btnGuardar.UseVisualStyleBackColor = true;
            // 
            // dtgAssets
            // 
            this.dtgAssets.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.DisplayedCellsExceptHeader;
            this.dtgAssets.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtgAssets.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Fecha,
            this.Moneda,
            this.inv_cant,
            this.inv_BTC,
            this.inv_USD,
            this.inv_cop});
            this.dtgAssets.Location = new System.Drawing.Point(16, 41);
            this.dtgAssets.Name = "dtgAssets";
            this.dtgAssets.RowTemplate.Height = 24;
            this.dtgAssets.Size = new System.Drawing.Size(755, 188);
            this.dtgAssets.TabIndex = 2;
            // 
            // Fecha
            // 
            this.Fecha.HeaderText = "Fecha";
            this.Fecha.Name = "Fecha";
            this.Fecha.Width = 24;
            // 
            // Moneda
            // 
            this.Moneda.HeaderText = "Moneda";
            this.Moneda.Name = "Moneda";
            this.Moneda.Width = 24;
            // 
            // inv_cant
            // 
            this.inv_cant.HeaderText = "Unidades";
            this.inv_cant.Name = "inv_cant";
            this.inv_cant.Width = 24;
            // 
            // inv_BTC
            // 
            this.inv_BTC.HeaderText = "BTC";
            this.inv_BTC.Name = "inv_BTC";
            this.inv_BTC.Width = 24;
            // 
            // inv_USD
            // 
            this.inv_USD.HeaderText = "USD";
            this.inv_USD.Name = "inv_USD";
            this.inv_USD.Width = 24;
            // 
            // inv_cop
            // 
            this.inv_cop.HeaderText = "COP";
            this.inv_cop.Name = "inv_cop";
            this.inv_cop.Width = 24;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.dtgAssestHitBTC);
            this.tabPage2.Location = new System.Drawing.Point(4, 25);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(789, 235);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Inventario";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // dtgAssestHitBTC
            // 
            this.dtgAssestHitBTC.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.DisplayedCellsExceptHeader;
            this.dtgAssestHitBTC.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtgAssestHitBTC.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn10,
            this.dataGridViewTextBoxColumn11,
            this.dataGridViewTextBoxColumn12,
            this.dataGridViewTextBoxColumn13,
            this.dataGridViewTextBoxColumn14});
            this.dtgAssestHitBTC.Location = new System.Drawing.Point(6, 8);
            this.dtgAssestHitBTC.Name = "dtgAssestHitBTC";
            this.dtgAssestHitBTC.RowTemplate.Height = 24;
            this.dtgAssestHitBTC.Size = new System.Drawing.Size(769, 209);
            this.dtgAssestHitBTC.TabIndex = 1;
     //       this.dtgAssestHitBTC.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.//dtgAssestHitBTC_CellContentClick);
            // 
            // dataGridViewTextBoxColumn10
            // 
            this.dataGridViewTextBoxColumn10.HeaderText = "Moneda";
            this.dataGridViewTextBoxColumn10.Name = "dataGridViewTextBoxColumn10";
            this.dataGridViewTextBoxColumn10.Width = 24;
            // 
            // dataGridViewTextBoxColumn11
            // 
            this.dataGridViewTextBoxColumn11.HeaderText = "Cta_Banco_Un";
            this.dataGridViewTextBoxColumn11.Name = "dataGridViewTextBoxColumn11";
            this.dataGridViewTextBoxColumn11.Width = 24;
            // 
            // dataGridViewTextBoxColumn12
            // 
            this.dataGridViewTextBoxColumn12.HeaderText = "Cta_Trading_Un";
            this.dataGridViewTextBoxColumn12.Name = "dataGridViewTextBoxColumn12";
            this.dataGridViewTextBoxColumn12.Width = 24;
            // 
            // dataGridViewTextBoxColumn13
            // 
            this.dataGridViewTextBoxColumn13.HeaderText = "Total_Unidades";
            this.dataGridViewTextBoxColumn13.Name = "dataGridViewTextBoxColumn13";
            this.dataGridViewTextBoxColumn13.Width = 24;
            // 
            // dataGridViewTextBoxColumn14
            // 
            this.dataGridViewTextBoxColumn14.HeaderText = "USD";
            this.dataGridViewTextBoxColumn14.Name = "dataGridViewTextBoxColumn14";
            this.dataGridViewTextBoxColumn14.Width = 24;
            // 
            // cmdTEst
            // 
            this.cmdTEst.Location = new System.Drawing.Point(1166, 49);
            this.cmdTEst.Name = "cmdTEst";
            this.cmdTEst.Size = new System.Drawing.Size(76, 37);
            this.cmdTEst.TabIndex = 3;
            this.cmdTEst.Text = "test";
            this.cmdTEst.UseVisualStyleBackColor = true;
            this.cmdTEst.Click += new System.EventHandler(this.cmdTEst_Click);
            // 
            // gpAlarmas
            // 
            this.gpAlarmas.Controls.Add(this.dtAlarmas);
            this.gpAlarmas.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gpAlarmas.Location = new System.Drawing.Point(12, 756);
            this.gpAlarmas.Name = "gpAlarmas";
            this.gpAlarmas.Size = new System.Drawing.Size(1124, 291);
            this.gpAlarmas.TabIndex = 45;
            this.gpAlarmas.TabStop = false;
            this.gpAlarmas.Text = "Alarmas";
            // 
            // dtAlarmas
            // 
            this.dtAlarmas.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.dtAlarmas.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtAlarmas.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewTextBoxColumn6,
            this.dataGridViewTextBoxColumn7,
            this.dataGridViewTextBoxColumn8});
            this.dtAlarmas.Location = new System.Drawing.Point(17, 27);
            this.dtAlarmas.Name = "dtAlarmas";
            this.dtAlarmas.RowTemplate.Height = 24;
            this.dtAlarmas.Size = new System.Drawing.Size(1101, 258);
            this.dtAlarmas.TabIndex = 0;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.HeaderText = "Fecha";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.Width = 81;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.HeaderText = "Moneda";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.Width = 94;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.HeaderText = "BTC";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.Width = 67;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.HeaderText = "USD";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.Width = 69;
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.HeaderText = "COP";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            this.dataGridViewTextBoxColumn5.Width = 69;
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.HeaderText = "Cantidad";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            this.dataGridViewTextBoxColumn6.Width = 101;
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.HeaderText = "AlarmaAlta";
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            this.dataGridViewTextBoxColumn7.Width = 115;
            // 
            // dataGridViewTextBoxColumn8
            // 
            this.dataGridViewTextBoxColumn8.HeaderText = "AlarmaBaja";
            this.dataGridViewTextBoxColumn8.Name = "dataGridViewTextBoxColumn8";
            this.dataGridViewTextBoxColumn8.Width = 119;
            // 
            // gpLog
            // 
            this.gpLog.Controls.Add(this.btnBitacora);
            this.gpLog.Controls.Add(this.btnLog);
            this.gpLog.Controls.Add(this.rtxtLog);
            this.gpLog.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gpLog.Location = new System.Drawing.Point(1142, 756);
            this.gpLog.Name = "gpLog";
            this.gpLog.Size = new System.Drawing.Size(783, 213);
            this.gpLog.TabIndex = 46;
            this.gpLog.TabStop = false;
            this.gpLog.Text = "Log de Transacciones";
            // 
            // btnBitacora
            // 
            this.btnBitacora.Location = new System.Drawing.Point(148, 21);
            this.btnBitacora.Name = "btnBitacora";
            this.btnBitacora.Size = new System.Drawing.Size(121, 24);
            this.btnBitacora.TabIndex = 46;
            this.btnBitacora.Text = "Ver Bitácora";
            this.btnBitacora.UseVisualStyleBackColor = true;
            this.btnBitacora.Click += new System.EventHandler(this.btnBitacora_Click);
            // 
            // btnLog
            // 
            this.btnLog.Location = new System.Drawing.Point(32, 21);
            this.btnLog.Name = "btnLog";
            this.btnLog.Size = new System.Drawing.Size(84, 25);
            this.btnLog.TabIndex = 45;
            this.btnLog.Text = "Ver Log";
            this.btnLog.UseVisualStyleBackColor = true;
            this.btnLog.Click += new System.EventHandler(this.btnLog_Click);
            // 
            // rtxtLog
            // 
            this.rtxtLog.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.rtxtLog.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rtxtLog.ForeColor = System.Drawing.SystemColors.InactiveBorder;
            this.rtxtLog.Location = new System.Drawing.Point(17, 52);
            this.rtxtLog.Name = "rtxtLog";
            this.rtxtLog.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.Vertical;
            this.rtxtLog.Size = new System.Drawing.Size(760, 150);
            this.rtxtLog.TabIndex = 44;
            this.rtxtLog.Text = "";
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.archivoToolStripMenuItem,
            this.ayudaToolStripMenuItem,
            this.otroToolStripMenuItem,
            this.ayudaToolStripMenuItem1});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1906, 28);
            this.menuStrip1.TabIndex = 47;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // archivoToolStripMenuItem
            // 
            this.archivoToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.salirToolStripMenuItem});
            this.archivoToolStripMenuItem.Name = "archivoToolStripMenuItem";
            this.archivoToolStripMenuItem.Size = new System.Drawing.Size(71, 24);
            this.archivoToolStripMenuItem.Text = "Archivo";
            // 
            // salirToolStripMenuItem
            // 
            this.salirToolStripMenuItem.Name = "salirToolStripMenuItem";
            this.salirToolStripMenuItem.Size = new System.Drawing.Size(113, 26);
            this.salirToolStripMenuItem.Text = "Salir";
            this.salirToolStripMenuItem.Click += new System.EventHandler(this.salirToolStripMenuItem_Click);
            // 
            // ayudaToolStripMenuItem
            // 
            this.ayudaToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.configuraciónAPIKeyToolStripMenuItem,
            this.toolStripSeparator1,
            this.reglasDeDistribuciónToolStripMenuItem,
            this.redNeuronalToolStripMenuItem,
            this.toolStripSeparator2,
            this.estrategiasToolStripMenuItem});
            this.ayudaToolStripMenuItem.Name = "ayudaToolStripMenuItem";
            this.ayudaToolStripMenuItem.Size = new System.Drawing.Size(114, 24);
            this.ayudaToolStripMenuItem.Text = "Configuración";
            this.ayudaToolStripMenuItem.Click += new System.EventHandler(this.ayudaToolStripMenuItem_Click);
            // 
            // configuraciónAPIKeyToolStripMenuItem
            // 
            this.configuraciónAPIKeyToolStripMenuItem.Name = "configuraciónAPIKeyToolStripMenuItem";
            this.configuraciónAPIKeyToolStripMenuItem.Size = new System.Drawing.Size(233, 26);
            this.configuraciónAPIKeyToolStripMenuItem.Text = "Establecer API Key";
            this.configuraciónAPIKeyToolStripMenuItem.Click += new System.EventHandler(this.configuraciónAPIKeyToolStripMenuItem_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(230, 6);
            // 
            // reglasDeDistribuciónToolStripMenuItem
            // 
            this.reglasDeDistribuciónToolStripMenuItem.Name = "reglasDeDistribuciónToolStripMenuItem";
            this.reglasDeDistribuciónToolStripMenuItem.Size = new System.Drawing.Size(233, 26);
            this.reglasDeDistribuciónToolStripMenuItem.Text = "Reglas de Distribución";
            this.reglasDeDistribuciónToolStripMenuItem.Click += new System.EventHandler(this.reglasDeDistribuciónToolStripMenuItem_Click);
            // 
            // redNeuronalToolStripMenuItem
            // 
            this.redNeuronalToolStripMenuItem.Name = "redNeuronalToolStripMenuItem";
            this.redNeuronalToolStripMenuItem.Size = new System.Drawing.Size(233, 26);
            this.redNeuronalToolStripMenuItem.Text = "Red Neuronal";
            this.redNeuronalToolStripMenuItem.Click += new System.EventHandler(this.redNeuronalToolStripMenuItem_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(230, 6);
            // 
            // estrategiasToolStripMenuItem
            // 
            this.estrategiasToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.editorToolStripMenuItem,
            this.configuraciónToolStripMenuItem});
            this.estrategiasToolStripMenuItem.Name = "estrategiasToolStripMenuItem";
            this.estrategiasToolStripMenuItem.Size = new System.Drawing.Size(233, 26);
            this.estrategiasToolStripMenuItem.Text = "Estrategias";
            // 
            // editorToolStripMenuItem
            // 
            this.editorToolStripMenuItem.Name = "editorToolStripMenuItem";
            this.editorToolStripMenuItem.Size = new System.Drawing.Size(177, 26);
            this.editorToolStripMenuItem.Text = "Editor";
            this.editorToolStripMenuItem.Click += new System.EventHandler(this.editorToolStripMenuItem_Click);
            // 
            // configuraciónToolStripMenuItem
            // 
            this.configuraciónToolStripMenuItem.Name = "configuraciónToolStripMenuItem";
            this.configuraciónToolStripMenuItem.Size = new System.Drawing.Size(177, 26);
            this.configuraciónToolStripMenuItem.Text = "Configuración";
            this.configuraciónToolStripMenuItem.Click += new System.EventHandler(this.configuraciónToolStripMenuItem_Click);
            // 
            // otroToolStripMenuItem
            // 
            this.otroToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.activarBotToolStripMenuItem});
            this.otroToolStripMenuItem.Name = "otroToolStripMenuItem";
            this.otroToolStripMenuItem.Size = new System.Drawing.Size(44, 24);
            this.otroToolStripMenuItem.Text = "Bot";
            this.otroToolStripMenuItem.Click += new System.EventHandler(this.otroToolStripMenuItem_Click);
            // 
            // activarBotToolStripMenuItem
            // 
            this.activarBotToolStripMenuItem.Name = "activarBotToolStripMenuItem";
            this.activarBotToolStripMenuItem.Size = new System.Drawing.Size(157, 26);
            this.activarBotToolStripMenuItem.Text = "Activar Bot";
            this.activarBotToolStripMenuItem.Click += new System.EventHandler(this.activarBotToolStripMenuItem_Click);
            // 
            // ayudaToolStripMenuItem1
            // 
            this.ayudaToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.acercaDeToolStripMenuItem});
            this.ayudaToolStripMenuItem1.Name = "ayudaToolStripMenuItem1";
            this.ayudaToolStripMenuItem1.Size = new System.Drawing.Size(63, 24);
            this.ayudaToolStripMenuItem1.Text = "Ayuda";
            // 
            // acercaDeToolStripMenuItem
            // 
            this.acercaDeToolStripMenuItem.Name = "acercaDeToolStripMenuItem";
            this.acercaDeToolStripMenuItem.Size = new System.Drawing.Size(159, 26);
            this.acercaDeToolStripMenuItem.Text = "Acerca de...";
            this.acercaDeToolStripMenuItem.Click += new System.EventHandler(this.acercaDeToolStripMenuItem_Click);
            // 
            // statusStrip1
            // 
            this.statusStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel1,
            this.toolStripStatusLabel2,
            this.EstadoBot});
            this.statusStrip1.Location = new System.Drawing.Point(0, 929);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(1906, 25);
            this.statusStrip1.TabIndex = 48;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // toolStripStatusLabel1
            // 
            this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            this.toolStripStatusLabel1.Size = new System.Drawing.Size(83, 20);
            this.toolStripStatusLabel1.Text = "Cargando...";
            this.toolStripStatusLabel1.Click += new System.EventHandler(this.toolStripStatusLabel1_Click);
            // 
            // toolStripStatusLabel2
            // 
            this.toolStripStatusLabel2.Name = "toolStripStatusLabel2";
            this.toolStripStatusLabel2.Size = new System.Drawing.Size(37, 20);
            this.toolStripStatusLabel2.Text = "--->";
            // 
            // EstadoBot
            // 
            this.EstadoBot.Name = "EstadoBot";
            this.EstadoBot.Size = new System.Drawing.Size(151, 20);
            this.EstadoBot.Text = "toolStripStatusLabel2";
            this.EstadoBot.Click += new System.EventHandler(this.EstadoBot_Click);
            // 
            // dtOHLC
            // 
            this.dtOHLC.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.dtOHLC.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtOHLC.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn15,
            this.dataGridViewTextBoxColumn20,
            this.dataGridViewTextBoxColumn16,
            this.dataGridViewTextBoxColumn17,
            this.dataGridViewTextBoxColumn18,
            this.dataGridViewTextBoxColumn19,
            this.Volumen});
            this.dtOHLC.Location = new System.Drawing.Point(1079, 92);
            this.dtOHLC.Name = "dtOHLC";
            this.dtOHLC.RowTemplate.Height = 24;
            this.dtOHLC.Size = new System.Drawing.Size(823, 109);
            this.dtOHLC.TabIndex = 0;
            this.dtOHLC.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dtOHLC_CellContentClick);
            // 
            // dataGridViewTextBoxColumn15
            // 
            this.dataGridViewTextBoxColumn15.HeaderText = "Id";
            this.dataGridViewTextBoxColumn15.Name = "dataGridViewTextBoxColumn15";
            this.dataGridViewTextBoxColumn15.Width = 48;
            // 
            // dataGridViewTextBoxColumn20
            // 
            this.dataGridViewTextBoxColumn20.HeaderText = "Date";
            this.dataGridViewTextBoxColumn20.Name = "dataGridViewTextBoxColumn20";
            this.dataGridViewTextBoxColumn20.Width = 67;
            // 
            // dataGridViewTextBoxColumn16
            // 
            this.dataGridViewTextBoxColumn16.HeaderText = "Open";
            this.dataGridViewTextBoxColumn16.Name = "dataGridViewTextBoxColumn16";
            this.dataGridViewTextBoxColumn16.Width = 72;
            // 
            // dataGridViewTextBoxColumn17
            // 
            this.dataGridViewTextBoxColumn17.HeaderText = "Close";
            this.dataGridViewTextBoxColumn17.Name = "dataGridViewTextBoxColumn17";
            this.dataGridViewTextBoxColumn17.Width = 72;
            // 
            // dataGridViewTextBoxColumn18
            // 
            this.dataGridViewTextBoxColumn18.HeaderText = "High";
            this.dataGridViewTextBoxColumn18.Name = "dataGridViewTextBoxColumn18";
            this.dataGridViewTextBoxColumn18.Width = 66;
            // 
            // dataGridViewTextBoxColumn19
            // 
            this.dataGridViewTextBoxColumn19.HeaderText = "Low";
            this.dataGridViewTextBoxColumn19.Name = "dataGridViewTextBoxColumn19";
            this.dataGridViewTextBoxColumn19.Width = 62;
            // 
            // Volumen
            // 
            dataGridViewCellStyle2.Format = "0.0000000000";
            dataGridViewCellStyle2.NullValue = null;
            this.Volumen.DefaultCellStyle = dataGridViewCellStyle2;
            this.Volumen.HeaderText = "Volumen";
            this.Volumen.Name = "Volumen";
            this.Volumen.Width = 92;
            // 
            // candle
            // 
            chartArea2.Name = "ChartArea1";
            this.candle.ChartAreas.Add(chartArea2);
            this.candle.DataSource = this.candle.Annotations;
            legend2.Name = "Legend1";
            this.candle.Legends.Add(legend2);
            this.candle.Location = new System.Drawing.Point(1084, 254);
            this.candle.Name = "candle";
            series2.ChartArea = "ChartArea1";
            series2.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Candlestick;
            series2.Legend = "Legend1";
            series2.Name = "Diario";
            series2.YValuesPerPoint = 4;
            this.candle.Series.Add(series2);
            this.candle.Size = new System.Drawing.Size(818, 196);
            this.candle.TabIndex = 49;
            this.candle.Text = "Candles";
            this.candle.Visible = false;
            // 
            // btnupdate
            // 
            this.btnupdate.Location = new System.Drawing.Point(1431, 215);
            this.btnupdate.Name = "btnupdate";
            this.btnupdate.Size = new System.Drawing.Size(97, 23);
            this.btnupdate.TabIndex = 50;
            this.btnupdate.Text = "Actualizar";
            this.btnupdate.UseVisualStyleBackColor = true;
            this.btnupdate.Click += new System.EventHandler(this.btnupdate_Click);
            // 
            // tmrALT
            // 
            this.tmrALT.Interval = 20000;
            this.tmrALT.Tick += new System.EventHandler(this.tmrALT_Tick);
            // 
            // picConectado
            // 
            this.picConectado.BackColor = System.Drawing.SystemColors.Control;
            this.picConectado.ImageLocation = "";
            this.picConectado.Location = new System.Drawing.Point(1841, 31);
            this.picConectado.Name = "picConectado";
            this.picConectado.Size = new System.Drawing.Size(53, 48);
            this.picConectado.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picConectado.TabIndex = 53;
            this.picConectado.TabStop = false;
            this.picConectado.Click += new System.EventHandler(this.picConectado_Click);
            // 
            // lblvalordolar
            // 
            this.lblvalordolar.BackColor = System.Drawing.SystemColors.ControlDark;
            this.lblvalordolar.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblvalordolar.Location = new System.Drawing.Point(1079, 244);
            this.lblvalordolar.Name = "lblvalordolar";
            this.lblvalordolar.Size = new System.Drawing.Size(710, 425);
            this.lblvalordolar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.lblvalordolar.TabIndex = 54;
            this.lblvalordolar.TabStop = false;
            // 
            // btnTxHistory
            // 
            this.btnTxHistory.Location = new System.Drawing.Point(1870, 496);
            this.btnTxHistory.Name = "btnTxHistory";
            this.btnTxHistory.Size = new System.Drawing.Size(74, 49);
            this.btnTxHistory.TabIndex = 55;
            this.btnTxHistory.Text = "Obtener Historial";
            this.btnTxHistory.UseVisualStyleBackColor = true;
            this.btnTxHistory.Click += new System.EventHandler(this.btnTxHistory_Click);
            // 
            // frmPpal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.ClientSize = new System.Drawing.Size(1906, 954);
            this.Controls.Add(this.btnTxHistory);
            this.Controls.Add(this.lblvalordolar);
            this.Controls.Add(this.picConectado);
            this.Controls.Add(this.btnupdate);
            this.Controls.Add(this.candle);
            this.Controls.Add(this.dtOHLC);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.gpLog);
            this.Controls.Add(this.cmdTEst);
            this.Controls.Add(this.gpAssets);
            this.Controls.Add(this.grCryptoCurrency);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.gpAlarmas);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "frmPpal";
            this.Text = "Hexo-BOT";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.frmPpal_Load);
            this.grCryptoCurrency.ResumeLayout(false);
            this.grCryptoCurrency.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picCrypto5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picCrypto4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picCrypto3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picCrypto2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picCrypto1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.piBTC)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dtGCSV)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBTCbtc)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBTCusd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBTCcop)).EndInit();
            this.gpAssets.ResumeLayout(false);
            this.tabPortfolio.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dtgAssets)).EndInit();
            this.tabPage2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dtgAssestHitBTC)).EndInit();
            this.gpAlarmas.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dtAlarmas)).EndInit();
            this.gpLog.ResumeLayout(false);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtOHLC)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.candle)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picConectado)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblvalordolar)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox grCryptoCurrency;
        private System.Windows.Forms.PictureBox picBTCbtc;
        private System.Windows.Forms.PictureBox picBTCusd;
        private System.Windows.Forms.PictureBox picBTCcop;
        private System.Windows.Forms.DataGridView dtGCSV;
        private System.Windows.Forms.GroupBox gpAssets;
        private System.Windows.Forms.Button cmdTEst;
        private System.Windows.Forms.GroupBox gpAlarmas;
        private System.Windows.Forms.DataGridView dtAlarmas;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;
        private System.Windows.Forms.GroupBox gpLog;
        private System.Windows.Forms.RichTextBox rtxtLog;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem archivoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ayudaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem configuraciónAPIKeyToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem otroToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ayudaToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem acercaDeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem salirToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem activarBotToolStripMenuItem;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
        private System.Windows.Forms.ToolStripStatusLabel EstadoBot;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel2;
        private System.Windows.Forms.PictureBox picCrypto5;
        private System.Windows.Forms.PictureBox picCrypto4;
        private System.Windows.Forms.PictureBox picCrypto3;
        private System.Windows.Forms.PictureBox picCrypto2;
        private System.Windows.Forms.PictureBox picCrypto1;
        private System.Windows.Forms.PictureBox piBTC;
        private System.Windows.Forms.DataGridView dtOHLC;
        private System.Windows.Forms.DataVisualization.Charting.Chart candle;
        private System.Windows.Forms.Button btnupdate;
        private System.Windows.Forms.Label lblCrypto1;
        private System.Windows.Forms.Label lblCrypto6;
        private System.Windows.Forms.Label lblCrypto5;
        private System.Windows.Forms.Label lblCrypto4;
        private System.Windows.Forms.Label lblCrypto3;
        private System.Windows.Forms.Label lblCrypto2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn15;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn20;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn16;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn17;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn18;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn19;
        private System.Windows.Forms.DataGridViewTextBoxColumn Volumen;
        private System.Windows.Forms.Label lblDolarvl;
        private System.Windows.Forms.TextBox txtVlrDolar;
        private System.Windows.Forms.Timer tmrALT;
        private System.Windows.Forms.Timer tmrUSD;
        private System.Windows.Forms.PictureBox picConectado;
        private System.Windows.Forms.ToolStripMenuItem reglasDeDistribuciónToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem redNeuronalToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripMenuItem estrategiasToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripMenuItem editorToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem configuraciónToolStripMenuItem;
        private System.Windows.Forms.Button btnBitacora;
        private System.Windows.Forms.Button btnLog;
        private System.Windows.Forms.PictureBox lblvalordolar;
        private System.Windows.Forms.Button btnTxHistory;
        private System.Windows.Forms.TabControl tabPortfolio;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Button btnGuardar;
        private System.Windows.Forms.DataGridView dtgAssets;
        private System.Windows.Forms.DataGridViewTextBoxColumn Fecha;
        private System.Windows.Forms.DataGridViewTextBoxColumn Moneda;
        private System.Windows.Forms.DataGridViewTextBoxColumn inv_cant;
        private System.Windows.Forms.DataGridViewTextBoxColumn inv_BTC;
        private System.Windows.Forms.DataGridViewTextBoxColumn inv_USD;
        private System.Windows.Forms.DataGridViewTextBoxColumn inv_cop;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.DataGridView dtgAssestHitBTC;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn10;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn11;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn12;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn13;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn14;
        private System.Windows.Forms.DataGridViewImageColumn Logo;
        private System.Windows.Forms.DataGridViewTextBoxColumn CrytoMoneda;
        private System.Windows.Forms.DataGridViewTextBoxColumn BTC;
        private System.Windows.Forms.DataGridViewTextBoxColumn USD;
        private System.Windows.Forms.DataGridViewTextBoxColumn COP;
    }
}

